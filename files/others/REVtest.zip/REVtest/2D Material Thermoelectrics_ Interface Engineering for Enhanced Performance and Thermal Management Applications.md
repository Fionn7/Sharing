# 2D Material Thermoelectrics: Interface Engineering for Enhanced Performance and Thermal Management Applications

## Abstract

The relentless miniaturization of electronic devices has pushed thermal management to the forefront of technological challenges, with modern AI accelerators now exhibiting local heat flux densities exceeding 1 kW/cm²—far beyond the capabilities of conventional bulk thermoelectric materials like Bi₂Te₃ [(69)](https://www.zjcxtech.com/micro-thermoelectric-coolers-from-academic-breakthrough-to-practical-thermal-management-in-data-centers-and-beyond/). Two-dimensional (2D) materials, by virtue of their atomic-scale thickness and inherently low lattice thermal conductivity, have emerged as a transformative platform for next-generation thermoelectric (TE) cooling and energy harvesting. This review provides a comprehensive overview of the rapidly advancing field of 2D material thermoelectrics, with a particular focus on the critical role of interface engineering in decoupling electron and phonon transport—the long-standing bottleneck to high thermoelectric performance. We discuss the fundamental physical mechanisms governing thermal and electrical transport in 2D systems, including quantum confinement, topological surface states, and low-dimensional phonon dynamics. Key interface engineering strategies are analyzed in detail, from van der Waals heterostructures and defect engineering to substrate interactions, with an emphasis on experimental breakthroughs and their underlying theoretical insights. The review also highlights emerging 2D TE material systems and outlines pressing challenges and future opportunities for translating fundamental research into practical thermal management technologies.

## 1. Introduction

The past decade has witnessed an explosion of interest in 2D materials for thermoelectric applications, driven by two interlocking trends: the urgent need for efficient thermal management in high-power microelectronics and the fundamental discovery that 2D systems exhibit unique transport properties unattainable in bulk materials. As electronic devices scale to sub-3nm technology nodes, local heat flux densities have surged to unprecedented levels—surpassing 1 kW/cm² in state-of-the-art AI accelerators like NVIDIA's Verarubin series, where single-chip power consumption now exceeds 2000 W [(69)](https://www.zjcxtech.com/micro-thermoelectric-coolers-from-academic-breakthrough-to-practical-thermal-management-in-data-centers-and-beyond/). Conventional thermoelectric materials, most notably Bi₂Te₃ and its alloys, have long been the workhorses of solid-state cooling and waste heat recovery. However, their practical utility in these emerging high-heat-flux scenarios is fundamentally limited: Bi₂Te₃-based thin films can achieve peak ZT values of \~1.28 at room temperature, but their performance degrades sharply above 400 K, with ZT dropping below 0.5 at 200°C [(66)](https://www.jim.org.cn/CN/10.15541/jim20220736). Worse, in humid operating environments—common in data centers and consumer electronics—Bi₂Te₃ films lose nearly 30% of their TE performance within 600 hours due to surface oxidation and interface degradation [(66)](https://www.jim.org.cn/CN/10.15541/jim20220736). These limitations stem from a core trade-off in bulk materials: efforts to enhance the Seebeck coefficient (S) often reduce electrical conductivity (σ), while attempts to suppress thermal conductivity (κ) typically compromise carrier mobility—a challenge known as the "electron-phonon decoupling problem" that has stymied TE progress for decades.

Two-dimensional materials offer a pathway to overcome this bottleneck by virtue of their intrinsic structural and electronic properties. Unlike bulk materials, where heat and charge carriers propagate through three-dimensional lattices, 2D systems confine transport to a single atomic or molecular layer—introducing quantum confinement effects that fundamentally alter the density of states and phonon dispersion relations. For example, the room-temperature lattice thermal conductivity of bulk Bi₂Te₃ (\~1.2 W/mK) is already relatively low for a crystalline solid, but monolayer 2H-MoS₂ reduces this value by over an order of magnitude to just \~0.1–0.5 W/mK [(348)](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290). This dramatic suppression of lattice thermal conductivity (κ\_L) arises because 2D confinement shortens the mean free path of low-frequency phonons—precisely the phonons that dominate heat conduction in bulk materials—while simultaneously enhancing the Seebeck coefficient via quantum size effects that concentrate electronic states near the Fermi level [(348)](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290).

The figure of merit ZT = σS²T/κ—where T is absolute temperature and κ is total thermal conductivity (the sum of electronic (κ\_e) and lattice (κ\_L) contributions)—serves as the gold standard for evaluating TE performance. For 2D materials, early theoretical predictions suggested that ZT values could exceed 3.0 in idealized structures, far surpassing the \~1.0–1.5 typical of commercial Bi₂Te₃-based devices [(348)](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290). While experimental progress has lagged behind theory, recent breakthroughs have brought these targets within reach: for instance, Hf₂BS₂ monolayers have achieved a ZT of \~1.74 at 300 K without external strain or complex doping, already exceeding the peak performance of Bi₂Te₃ thin films [(348)](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290).

Interface engineering has emerged as the single most powerful strategy to unlock the full potential of 2D thermoelectrics. By tailoring the structure and chemistry of interfaces—whether between layers in a van der Waals heterostructure, between a 2D material and its substrate, or at defect sites within the material—researchers can independently manipulate electron and phonon transport. This is the essence of the modern TE paradigm: optimize the power factor (PF = σS²) through band structure engineering, while suppressing κ\_L through targeted phonon scattering.

This review provides a comprehensive overview of the current state of 2D material thermoelectrics, with a focus on the critical role of interfaces in modulating transport properties. We begin by establishing the fundamental theoretical framework for thermal and electrical transport in 2D systems, from quantum confinement effects to topological surface states. Next, we discuss the unique phonon dynamics of 2D materials and the role of interfaces in scattering phonons. We then delve into key interface engineering strategies, including van der Waals heterostructures, defect engineering, and substrate interactions, highlighting landmark experimental studies and their underlying theoretical insights. We also survey emerging 2D TE material systems and outline pressing challenges and future opportunities for the field.

## 2. Theoretical Framework: Transport in 2D Systems

To understand the potential of 2D materials for thermoelectrics and the role of interfaces in modulating performance, it is essential to first establish the fundamental physical mechanisms governing thermal and electrical transport in low-dimensional systems.

### 2.1 Electronic Transport: Quantum Confinement and Topological States

In 2D materials, electrons are confined to a plane, resulting in discrete energy levels (subbands) and a density of states (DOS) that deviates significantly from the parabolic behavior of bulk materials. This quantum confinement effect has profound implications for thermoelectric transport, most notably enhancing the Seebeck coefficient by concentrating electronic states near the Fermi level.

#### 2.1.1 Quantum Confinement and Seebeck Coefficient

The Seebeck coefficient S, a measure of a material's ability to convert a temperature gradient into electrical voltage, is fundamentally linked to the energy dependence of the electronic DOS and carrier mobility. For 2D systems, quantum confinement leads to a step-like DOS, which can significantly enhance S when the Fermi level is tuned to align with the edge of a subband. This effect is particularly pronounced in ultrathin films, where even small changes in thickness can lead to dramatic variations in TE performance.

Experimental studies on few-layer PdPS—a layered transition metal dichalcogenide (TMD) with intrinsic p-type conductivity—exemplify this thickness dependence with striking clarity. As reported in PhysRevB.102.125421, 11-layer PdPS films exhibit a Seebeck coefficient of approximately -700 μV/K at room temperature, a value that is nearly twice as large as the -400 μV/K measured in 88-layer films of the same material [(123)](https://poplab.stanford.edu/pdfs/Chen-AmbipolarThermoelectricWSe2-nl23.pdf). This dramatic difference arises because thinner films experience stronger quantum confinement: the electronic subbands become more discrete, and the DOS near the Fermi level is enhanced, amplifying the Seebeck coefficient. Similarly, systematic measurements of WSe₂ films across a thickness range of 10–96 nm show a monotonic decrease in the absolute Seebeck coefficient from \~500 μV/K to \~300 μV/K as thickness increases—confirming that quantum confinement is not just a theoretical curiosity but a practical lever for performance optimization [(123)](https://poplab.stanford.edu/pdfs/Chen-AmbipolarThermoelectricWSe2-nl23.pdf).

#### 2.1.2 Topological Surface States

A particularly exciting development in 2D thermoelectrics is the discovery of topological surface states (TSSs)—robust electronic states that exist at the surface of topological insulators and are protected by time-reversal symmetry. Unlike bulk states, which are localized to the interior of the material, TSSs are delocalized along the surface and exhibit Dirac-like dispersion, meaning their energy-momentum relation is linear rather than parabolic. This unique dispersion relation gives TSSs two key properties for thermoelectric applications: high carrier mobility (since they are immune to backscattering from non-magnetic defects) and the potential for large Seebeck coefficients when their contribution is optimized relative to bulk states.

For example, in Sb₂Te₃ thin films—a prototypical topological insulator—the topological surface state and bulk state exhibit opposite signs of the Seebeck coefficient: the surface state contributes a positive S, while the bulk state contributes a negative S [(154)](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c03871). This phenomenon allows researchers to tune the net Seebeck coefficient by adjusting the relative contributions of the two states via structural engineering. Specifically, reducing the grain size of Sb₂Te₃ films enhances the surface state contribution: fine-grained films (with average grain size < 50 nm) achieve a room-temperature electrical conductivity of \~1293 S/cm and a Seebeck coefficient of \~180 μV/K, compared to \~622 S/cm and \~120 μV/K in coarse-grained films (grain size > 200 nm) [(154)](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c03871). The origin of this effect lies in grain boundary scattering: smaller grains introduce more boundaries that scatter bulk carriers, reducing their contribution to transport and leaving the TSS—with its inherent immunity to backscattering—as the dominant current carrier.

Janus TMD structures—materials where one atomic layer is replaced by a different chalcogen (e.g., S or Se)—represent another powerful platform for leveraging topological effects to enhance TE performance. By breaking the out-of-plane mirror symmetry of conventional TMDs, Janus structures induce strong Rashba spin-orbit coupling, which splits the electronic bands and creates additional opportunities for band convergence. First-principles calculations for PtTeSe—a Janus TMD with a broken mirror symmetry—predict that 10% biaxial tensile strain can further enhance the Rashba effect, leading to a dramatic improvement in the Seebeck coefficient: at 700 K, p-type PtTeSe achieves a ZT of \~3.96, while n-type PtTeSe reaches \~2.38 [(360)](https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295). This performance far exceeds the theoretical limits of conventional TMDs, demonstrating the synergistic potential of topology and interface engineering.

#### 2.1.3 Band Convergence

Band convergence—where multiple valence or conduction bands are brought into alignment near the Fermi level—is a general strategy for enhancing the Seebeck coefficient without compromising electrical conductivity. In 2D materials, this effect can be induced by strain, alloying, or interface engineering, and it works by increasing the density of states at the Fermi level while preserving carrier mobility.

For example, in the Zintl phase compound Yb₁₄MnSb₁₁, the energy difference between the light and heavy hole bands is reduced to near zero, leading to a threefold increase in the Seebeck coefficient [(191)](https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html). This enhancement arises because the converged bands contribute a higher total DOS than a single band, amplifying the Seebeck coefficient while maintaining high carrier concentration. In 2D systems, similar effects have been observed in SnSe monolayers, where the orthorhombic crystal structure naturally leads to the convergence of two valence bands at the Γ point—resulting in a theoretical ZT of \~3.0 at 900 K, one of the highest predicted values for any 2D material [(348)](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290).

### 2.2 Phonon Transport: Low-Dimensional Dynamics and Interface Scattering

The lattice thermal conductivity (κ\_L) of 2D materials is typically several orders of magnitude lower than that of their bulk counterparts, a consequence of their reduced dimensionality and enhanced phonon scattering at interfaces and defects. Understanding and controlling these low-dimensional phonon dynamics is therefore critical for optimizing thermoelectric performance.

#### 2.2.1 Phonon Dispersion in 2D

In 2D materials, the confinement of phonons to a plane drastically alters their dispersion relations and mean free paths (MFPs). Unlike bulk materials, where phonons can propagate in all three dimensions, 2D phonons are restricted to in-plane motion, and their out-of-plane motion is quantized into discrete modes. This quantization leads to a significant reduction in the group velocity of low-frequency phonons—precisely the phonons that dominate heat conduction in bulk materials—thereby suppressing κ\_L.

For instance, the room-temperature in-plane thermal conductivity of bulk WSe₂ is approximately 50 W/mK, but this value drops to just \~10 W/mK in monolayer WSe₂ [(250)](https://media.sciltp.com/articles/2603003373/2603003373.pdf). Even more dramatic reductions are observed in disordered systems: twisted bilayer WSe₂, where the two layers are rotated relative to each other by a small angle, exhibits a cross-plane thermal conductivity of \~0.05 W/mK—four orders of magnitude lower than the in-plane value [(190)](https://pubs.rsc.org/en/content/articlepdf/2025/na/d5na00303b). This extreme anisotropy arises from the weak van der Waals coupling between the twisted layers, which limits the propagation of out-of-plane phonons while preserving in-plane transport.

Janus structures further modify phonon dispersion by introducing mass and force constant asymmetries. For example, in Janus MoSSe monolayers, the substitution of one S layer with Se creates a local mass imbalance that softens the phonon modes and enhances anharmonic scattering—resulting in a room-temperature lattice thermal conductivity of \~0.02 W/mK, among the lowest reported for any crystalline 2D material [(352)](https://pubs.acs.org/doi/10.1021/acsaem.4c01336). This effect is amplified by the broken mirror symmetry of the Janus structure, which introduces additional scattering channels for mid-frequency phonons.

#### 2.2.2 Interface Scattering Mechanisms

Interfaces—whether between layers in a heterostructure, between a 2D material and its substrate, or at defect sites—act as powerful phonon scatterers. In 2D systems, these interfaces can be engineered to target specific phonon frequencies, enabling full-spectrum suppression of κ\_L.



* **Isotope Scattering**: Isotopic substitution introduces mass fluctuations that scatter phonons without significantly altering the electronic band structure. For example, replacing 70% of natural Ge (which consists of 20% ⁷⁰Ge, 27% ⁷²Ge, and 53% ⁷⁴Ge) with ⁷⁶Ge in GeTe/Sb₂Te₃ superlattices reduces the lattice thermal conductivity by \~30% [(191)](https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html). This effect is particularly effective for high-frequency phonons, which have short MFPs and are most sensitive to local mass variations.

* **Alloy Scattering**: Random alloying creates compositional disorder that scatters mid-frequency phonons. In PbTe₀.₅Se₀.₅, for instance, the random distribution of Te and Se atoms introduces local strain fields that scatter phonons with MFPs between 1 and 10 nm, reducing κ\_L by \~40% [(191)](https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html). Unlike isotope scattering, alloy scattering can also modify the electronic band structure—creating opportunities for simultaneous optimization of σ and κ\_L.

* **Grain Boundary Scattering**: Grain boundaries are extended defects that scatter low-frequency phonons (MFPs > 10 nm). In nanocrystalline BiSbTe alloys, reducing the grain size to \~10 nm reduces κ\_L to \~0.2 W/mK—less than half the value of coarse-grained samples [(191)](https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html). This effect is critical for thin-film TE devices, where grain size can be precisely controlled via deposition conditions.

* **Four-Phonon Scattering**: While three-phonon scattering is the dominant anharmonic mechanism in most bulk materials, four-phonon scattering becomes increasingly important in 2D systems due to reduced dimensionality and enhanced anharmonicity. In single-layer g-SbC—a 2D metal carbide with a honeycomb lattice—first-principles calculations show that four-phonon scattering contributes \~30% of the total lattice thermal resistance at room temperature, with the remainder coming from three-phonon processes [(165)](https://pubs.rsc.org/en/content/articlepdf/2025/nr/d5nr02299a). This strong anharmonicity is a direct result of the 2D confinement, which increases the probability of multi-phonon interactions by restricting phonon motion to a plane.

### 2.3 Theoretical Models and Computational Approaches

Understanding transport in 2D materials requires a combination of first-principles calculations and semi-classical models, as quantum confinement and strong electron-phonon coupling often invalidate the approximations used for bulk systems.

#### 2.3.1 Boltzmann Transport Equation (BTE)

The semi-classical Boltzmann Transport Equation (BTE) is the workhorse of TE transport modeling, describing the evolution of carrier distributions under external gradients. In 2D systems, the BTE must be modified to account for quantum confinement and reduced dimensionality—most notably by replacing the 3D density of states with its 2D step-like counterpart.

A common approximation in BTE calculations is the Relaxation Time Approximation (RTA), which assumes that carriers relax to equilibrium exponentially with a single relaxation time τ. While RTA is computationally efficient and works well for many 2D systems (e.g., graphene and h-BN), it fails to capture strong electron-phonon coupling or non-parabolic band structures. For example, in transition metal dichalcogenides like MoS₂, where electron-phonon coupling is enhanced by the 2D confinement, RTA overestimates the electrical conductivity by \~20% [(111)](https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790).

For more accurate calculations, iterative solutions of the BTE—such as those implemented in the ShengBTE package—are required. These methods solve the BTE self-consistently, accounting for multiple scattering mechanisms and non-parabolic band effects. For instance, calculations for NbSe₂ using ShengBTE show that electron-phonon coupling reduces the electrical conductivity by \~30% compared to RTA predictions, highlighting the importance of including these effects for quantitative agreement with experiments [(111)](https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790).

#### 2.3.2 Molecular Dynamics (MD) Simulations

Molecular dynamics (MD) simulations provide a complementary approach to BTE calculations, enabling the study of phonon transport in 2D materials at the atomic scale. By modeling the motion of individual atoms and solving Newton's equations of motion, MD simulations can capture anharmonic effects—such as four-phonon scattering—that are difficult to treat with BTE.

For example, equilibrium MD (EMD) simulations of single-layer MoS₂ predict a room-temperature thermal conductivity of \~1.35 W/mK, which is in good agreement with experimental measurements using the 3ω method [(122)](https://pubs.acs.org/doi/abs/10.1021/acsami.1c24488). Non-equilibrium MD (NEMD) simulations—where a temperature gradient is applied across the system—have been used to study interface thermal resistance in van der Waals heterostructures. These simulations show that the thermal boundary conductance (TBC) between MoS₂ and h-BN is \~17 MW/m²K, which is \~3 times smaller than the TBC between graphene and h-BN [(122)](https://pubs.acs.org/doi/abs/10.1021/acsami.1c24488). This difference arises from the weaker van der Waals coupling between MoS₂ and h-BN, which limits phonon transmission across the interface.

#### 2.3.3 First-Principles Calculations

First-principles calculations based on density functional theory (DFT) are essential for predicting the electronic structure and transport properties of 2D materials. These calculations can predict band gaps, carrier effective masses, and electron-phonon coupling constants—all of which are critical for designing high-performance TE materials.

For example, DFT calculations for SnSe monolayers predict a maximum ZT of \~3.0 at 900 K, which is among the highest values reported for any 2D material [(348)](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290). This prediction has motivated numerous experimental studies aimed at synthesizing high-quality SnSe monolayers and verifying the theoretical performance. Similarly, DFT calculations for Janus PtTeSe predict that 10% biaxial tensile strain can enhance the Seebeck coefficient by \~50%, leading to a ZT of \~3.96 at 700 K [(360)](https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295). While these calculations are computationally intensive—requiring supercomputing resources for large systems—they provide a critical roadmap for experimental work.

## 3. Interface Engineering Strategies

Interface engineering is the cornerstone of modern thermoelectric research, as it allows for the independent manipulation of electron and phonon transport. In 2D materials, interfaces can be tailored at the atomic scale, leading to unprecedented control over transport properties.

### 3.1 van der Waals Heterostructures

Van der Waals (vdW) heterostructures—stacked assemblies of 2D materials held together by weak vdW forces—represent one of the most versatile platforms for interface engineering. Unlike conventional heterostructures, which require lattice matching between layers, vdW heterostructures can be formed from any combination of 2D materials, enabling the creation of artificial structures with tailored electronic and phononic properties.

#### 3.1.1 Vertical Heterostructures

Vertical vdW heterostructures are formed by stacking 2D materials in a layer-by-layer fashion, with the interface between layers acting as a critical modulator of transport. By controlling the stacking order, twist angle, and interlayer distance, researchers can tune both electronic and phononic properties to optimize TE performance.



* **Twistronics**: The twist angle between layers in a vdW heterostructure has a profound effect on transport properties, as it modulates the interlayer coupling strength and creates moiré superlattices that scatter phonons. For example, MoSe₂/WSe₂ heterostructures with a twist angle of 21.79° achieve a ZT value \~40% higher than that of untwisted heterostructures [(169)](https://pubmed.ncbi.nlm.nih.gov/38190725/). This enhancement arises from two complementary effects: the moiré superlattice scatters mid-frequency phonons, reducing κ\_L, while the twist angle optimizes the interlayer electronic coupling, enhancing the power factor. Even more dramatic effects are observed in twisted bilayer PdSe₂: a 90° twist angle results in a ZT of \~3.95 at 300 K and \~6.25 at 600 K—an 81% improvement over untwisted bilayer PdSe₂ [(352)](https://pubs.acs.org/doi/10.1021/acsaem.4c01336).

* **Stacking Order**: The relative orientation of layers in a vdW heterostructure also influences transport properties. For GeS/GeSe heterostructures, first-principles calculations show that the XY-stacked configuration (staggered layers) has a slightly higher ZT (0.83 at 800 K) than the XX-stacked configuration (aligned layers, 0.84 at 800 K) [(169)](https://pubmed.ncbi.nlm.nih.gov/38190725/). While the ZT difference is small, the XY-stacked configuration is significantly more stable—making it the preferred structure for experimental realization.

* **Interlayer Distance**: The interlayer distance in vdW heterostructures can be tuned by applying pressure or inserting spacer layers, providing another lever for controlling transport. For example, inserting a monolayer of h-BN between MoS₂ and a SiO₂ substrate increases the interlayer distance by \~0.3 Å, reducing the substrate-induced phonon scattering and increasing the room-temperature thermal conductivity of MoS₂ from \~38 W/mK to \~68 W/mK [(239)](https://poplab.stanford.edu/pdfs/Gabourie-SubstrateDepMoS2thermalK-jap22.pdf). This effect is particularly important for flexible TE devices, where substrate interactions can dominate transport properties.

#### 3.1.2 Lateral Heterostructures

Lateral vdW heterostructures—formed by stitching together different 2D materials in the same plane—offer unique opportunities for band structure engineering and energy filtering. Unlike vertical heterostructures, which modulate transport perpendicular to the plane, lateral heterostructures control transport in the plane of the material—making them ideal for in-plane TE devices.

For example, lateral MoS₂-MoSe₂ heterostructures exhibit type-II band alignment, where the conduction band minimum of MoSe₂ is lower than that of MoS₂, and the valence band maximum of MoS₂ is higher than that of MoSe₂ [(220)](https://advanced.onlinelibrary.wiley.com/doi/full/10.1002/admi.202202339). This alignment creates a built-in electric field at the interface, which filters low-energy electrons—enhancing the Seebeck coefficient by \~20% compared to pure MoS₂. Similarly, Bi₂Te₂.₇Se₀.₃/Graphene lateral heterostructures achieve a room-temperature Seebeck coefficient of \~220 μV/K and a power factor of \~40 μW/cmK²—both significantly higher than values for pure Bi₂Te₂.₇Se₀.₃ [(219)](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c12988). The enhancement arises from the energy filtering effect: the graphene layer acts as a high-mobility channel for high-energy electrons, while the Bi₂Te₂.₇Se₀.₃ layer provides a high Seebeck coefficient—combining to create a synergistic improvement in performance.

### 3.2 Defect Engineering

Defect engineering involves the intentional introduction of point defects, line defects, or planar defects to scatter phonons while preserving electron transport. In 2D materials, defects can be tailored to target specific phonon frequencies, enabling precise control over κ\_L.

#### 3.2.1 Vacancy Engineering

Vacancies—missing atoms in the crystal lattice—are one of the most effective tools for suppressing κ\_L in 2D materials. By introducing local mass and strain fluctuations, vacancies scatter phonons across a broad range of frequencies, with their effectiveness depending on the type and concentration of the vacancy.



* **Chalcogen Vacancies**: In MoS₂, sulfur vacancies (V\_S) are particularly effective at reducing κ\_L: a 1% V\_S concentration reduces the room-temperature thermal conductivity by \~60% [(243)](https://pubs.acs.org/doi/10.1021/acs.jpcc.3c06820). This effect is amplified by the large mass difference between S and the surrounding Mo atoms, which creates strong local strain fields that scatter mid-frequency phonons.

* **Transition Metal Vacancies**: Tungsten vacancies (V\_W) in WSe₂ are even more effective: a 1% V\_W concentration reduces κ\_L by \~70% at room temperature [(247)](https://pubmed.ncbi.nlm.nih.gov/35349994/). This is because W is much heavier than Se, so a W vacancy creates a larger mass fluctuation than a Se vacancy—making it a stronger phonon scatterer.

* **Divacancies**: In n-type SnSe, divacancies (two adjacent missing atoms) induce resonance levels near the Fermi level, enhancing the Seebeck coefficient by \~30% while reducing κ\_L by \~40% [(233)](https://scholars.cityu.edu.hk/en/publications/defect-engineering-boosted-ultrahigh-thermoelectric-power-conversion-efficiency-in-polycrystalline-snse\(101f9eb4-24be-4fb8-b38f-c87ef1bdaa40\).html). This dual effect—simultaneously improving the power factor and suppressing thermal conductivity—leads to a peak ZT of \~2.4 at 800 K, one of the highest values reported for any 2D material.

#### 3.2.2 Doping and Alloying

Doping and alloying introduce intentional impurities into the crystal lattice, modifying the electronic band structure and creating phonon scattering centers. Unlike vacancies, which primarily affect κ\_L, doping and alloying can be used to tune both the electronic and phononic properties of 2D materials.



* **ZnSb Doping**: In Bi₂Te₃, ZnSb doping compensates for Sb vacancies—reducing the carrier concentration from \~10²⁰ cm⁻³ to \~10¹⁹ cm⁻³—and enhances the Seebeck coefficient by \~25% [(249)](https://www.researchgate.net/publication/404399590_Coupled_Vacancy_and_Phonon-Scattering_Engineering_Drive_Defect_Evolution_Toward_Multifunctional_High-Performance_Bi2Te3_Thermoelectrics). Concurrently, the doping introduces hierarchical phonon scattering centers—from atomic-scale mass fluctuations to mesoscale twin boundaries—that reduce κ\_L by \~30%. The optimized composition (Bi₀.₄Sb₁.₆Te₂.₉₇Se₀.₀₄ + 0.15% ZnSb) achieves a peak ZT of \~1.56 at 348 K.

* **Se Alloying**: In PbTe₀.₅Se₀.₅, random alloying creates local strain fields that scatter phonons with MFPs between 1 and 10 nm, reducing κ\_L by \~40% [(191)](https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html). This effect is particularly effective for mid-frequency phonons, which dominate heat conduction in bulk PbTe.

* **N-Type Doping**: In Mg₃Sb₂, Te doping introduces n-type carriers and enhances the Seebeck coefficient by \~20%—resulting in a ZT of \~1.2 at 473 K [(327)](https://pubs.acs.org/doi/pdf/10.1021/acs.chemmater.5c01463). The enhancement arises from the formation of a resonant level near the conduction band minimum, which increases the DOS at the Fermi level.

#### 3.2.3 Grain Boundaries and Dislocations

Grain boundaries and dislocations are extended defects that scatter low-frequency phonons—precisely the phonons that are most difficult to suppress with point defects. In 2D materials, these defects can be controlled via synthesis conditions, enabling the creation of hierarchical scattering architectures that target all phonon frequency ranges.



* **Grain Boundaries**: In nanocrystalline BiSbTe alloys, reducing the grain size to \~10 nm reduces κ\_L to \~0.2 W/mK—less than half the value of coarse-grained samples [(191)](https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html). This effect is critical for thin-film TE devices, where grain size can be precisely controlled via sputtering or chemical vapor deposition (CVD).

* **Dislocations**: In Pb₀.₉₅Sb₀.₀₃Se, dense dislocations (10¹⁴ cm⁻²) are induced by intentional cation vacancies and thermal annealing [(251)](https://pmc.ncbi.nlm.nih.gov/articles/PMC7261317/). These dislocations scatter phonons with MFPs > 10 nm, reducing κ\_L by \~50% while preserving electrical conductivity. The optimized composition achieves a peak ZT of \~2.2 at 773 K.

### 3.3 Substrate and Encapsulation Effects

The interaction between a 2D material and its substrate or encapsulation layer can significantly modify its thermal and electrical transport properties. These interactions can be exploited to enhance TE performance by reducing substrate-induced phonon scattering or improving material stability.

#### 3.3.1 Substrate Coupling

The strength of the interaction between a 2D material and its substrate determines the extent to which the substrate affects phonon transport. van der Waals substrates (e.g., h-BN) have weak interactions with 2D materials, preserving their intrinsic transport properties, while covalent substrates (e.g., SiO₂) have strong interactions that enhance phonon scattering.



* **h-BN Substrates**: For MoS₂, the room-temperature in-plane thermal conductivity is \~68 W/mK on h-BN—nearly twice the value of \~38 W/mK on SiO₂ [(239)](https://poplab.stanford.edu/pdfs/Gabourie-SubstrateDepMoS2thermalK-jap22.pdf). This difference arises because h-BN is a vdW substrate, so it does not couple strongly to the low-frequency phonons of MoS₂. In contrast, SiO₂ is a covalent substrate, and its strong interaction with MoS₂ phonons enhances scattering and reduces thermal conductivity.

* **Strain Engineering**: Substrate-induced strain can also be used to modify the electronic band structure of 2D materials. For example, stretching a polymer substrate by 1% induces biaxial strain in a supported MoS₂ monolayer, reducing the band gap by \~10% and enhancing the electrical conductivity by \~15% [(192)](https://pdfs.semanticscholar.org/93c4/141ff206135bbee1990f069d4bed63ad4f0c.pdf). This effect is particularly useful for flexible TE devices, where substrate strain can be integrated into the device design.

#### 3.3.2 Encapsulation

Encapsulation layers protect 2D materials from environmental degradation and can modify their transport properties by introducing strain or reducing substrate interactions. For air-sensitive materials like black phosphorus, encapsulation is essential for maintaining TE performance over time.



* **h-BN Encapsulation**: Monolayer MoS₂ encapsulated in h-BN can withstand annealing at 550°C in air without significant degradation, whereas bare MoS₂ on SiO₂ degrades at 300°C [(244)](https://pubmed.ncbi.nlm.nih.gov/35541259/). This enhanced stability is critical for high-temperature TE applications, where materials must operate in harsh environments.

* **PMMA Encapsulation**: For black phosphorus, PMMA encapsulation reduces the rate of ambient degradation by \~90%, with the Seebeck coefficient remaining stable at \~-150 μV/K for 30 days—compared to a 50% degradation in bare samples [(268)](https://pmc.ncbi.nlm.nih.gov/articles/PMC7770910/). The PMMA layer acts as a barrier to oxygen and moisture, preventing the formation of phosphorus oxides that degrade transport properties.

## 4. Emerging 2D Thermoelectric Material Systems

Several 2D material systems have emerged as particularly promising for thermoelectric applications, each with unique properties that can be tailored via interface engineering.

### 4.1 MXenes

MXenes—a family of 2D transition metal carbides, nitrides, and carbonitrides—have attracted significant attention for TE applications due to their high electrical conductivity (up to 35,000 S/cm) and tunable surface chemistry [(329)](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/). Unlike most 2D materials, MXenes are metallic or semi-metallic, making them ideal for applications where high electrical conductivity is required.



* **Structure and Properties**: MXenes are typically synthesized by selectively etching the A layer from MAX phase precursors (e.g., Ti₃AlC₂), resulting in 2D flakes with surface terminations (e.g., -O, -OH, -Cl) that can be tailored via post-synthesis treatment. These terminations play a critical role in TE performance: Ti₃C₂Cl₂—synthesized via a Lewis acidic molten salt (GLS) method that produces clean, ordered Cl terminations—exhibits a 160-fold enhancement in macroscopic conductivity and a 13-fold enhancement in terahertz conductivity relative to conventional Cl/O-terminated Ti₃C₂ [(274)](https://www.mpi-halle.mpg.de/857946/2026-01-27-rn-smfd?print=yes). This improvement arises from minimized electron trapping at surface defects, which preserves carrier mobility.

* **Thermoelectric Performance**: While MXenes have low Seebeck coefficients (typically -10 to -50 μV/K) due to their high carrier concentrations, composites with other TE materials have shown promise. For example, Ti₃C₂Tₓ/Bi₂S₃ composites achieve a ZT of \~0.8 at 710 K—2.69 times higher than pure Bi₂S₃ [(356)](https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651). The enhancement arises from two effects: the MXene acts as a conductive network to improve electrical conductivity, and its surface terminations induce strong phonon scattering to reduce κ\_L.

* **Challenges**: MXenes face significant challenges for practical application, including poor oxidative stability (Ti₃C₂Tₓ degrades in aqueous media within days to weeks) and synthesis limitations (most methods rely on hazardous HF or LiF/HCl etchants) [(274)](https://www.mpi-halle.mpg.de/857946/2026-01-27-rn-smfd?print=yes). These challenges must be addressed before MXenes can be deployed in commercial TE devices.

### 4.2 Transition Metal Dichalcogenides (TMDs)

TMDs—materials with the general formula MX₂, where M is a transition metal and X is a chalcogen—are among the most widely studied 2D materials for TE applications. Their layered structure and tunable band gaps make them ideal for interface engineering.



* **Janus TMDs**: Janus TMDs—formed by replacing one chalcogen layer with another—exhibit broken out-of-plane mirror symmetry and strong Rashba spin-orbit coupling, leading to enhanced TE performance. For example, PtTeSe achieves a ZT of \~3.96 at 700 K under 10% biaxial strain [(360)](https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295). Similarly, Janus WSTe monolayers achieve a ZT of \~2.56 at high temperatures, attributed to strong anharmonicity and low κ\_L.

* **Alloyed TMDs**: Alloying TMDs can enhance band convergence and reduce κ\_L. For example, ZrSeS₀.₅Te₀.₅—a quasi-ternary Janus TMD—achieves a ZT of \~2.34 at 1000 K for p-type carriers [(285)](https://pubs.aip.org/aip/jap/article-pdf/doi/10.1063/5.0277369/20560911/235103_1_5.0277369.pdf). The enhancement arises from phonon softening, conductive network formation, and optimal band alignment.

* **Challenges**: TMDs face challenges including low Seebeck coefficients in metallic TMDs (e.g., TiS₂) and poor environmental stability in air-sensitive TMDs (e.g., TiSe₂) [(289)](https://pubs.acs.org/doi/full/10.1021/acsomega.1c00457). For example, TiSe₂ oxidizes in air within hours, making long-term use in unencapsulated devices impossible.

### 4.3 Black Phosphorus and Phosphorene

Black phosphorus—a layered semiconductor with a puckered honeycomb structure—exhibits high carrier mobility (up to 10,000 cm²/Vs) and a tunable direct band gap (from 0.3 eV in bulk to 2.0 eV in monolayer phosphorene) [(270)](https://www.researchgate.net/publication/364760123_Enhanced_Thermoelectric_Performance_in_Black_Phosphorene_via_Tunable_Interlayer_Twist). These properties make it ideal for TE applications in the mid-temperature range (300–500 K).



* **Thermoelectric Performance**: Phosphorene nanoribbons exhibit a ZT of \~1.41 along the armchair direction at 700 K—nearly 50% higher than bulk black phosphorus [(263)](https://pmc.ncbi.nlm.nih.gov/articles/PMC12156281/pdf/materials-18-02506.pdf). This enhancement arises from quantum confinement effects that enhance the Seebeck coefficient. Twisted bilayer black phosphorus (tbBP) further enhances performance: a 6° twist angle results in a ZT of \~1.8 at 500 K, attributed to moiré flat bands that enhance the Seebeck coefficient and strong anharmonic phonon scattering that reduces κ\_L [(270)](https://www.researchgate.net/publication/364760123_Enhanced_Thermoelectric_Performance_in_Black_Phosphorene_via_Tunable_Interlayer_Twist).

* **Challenges**: Black phosphorus faces significant challenges, including ambient instability (bare samples degrade in air within hours) and synthesis limitations (mechanical exfoliation yields low-quality samples with uncontrollable thickness) [(268)](https://pmc.ncbi.nlm.nih.gov/articles/PMC7770910/). Encapsulation with h-BN or PMMA can mitigate degradation, but large-scale synthesis of high-quality phosphorene remains a barrier to commercialization.

### 4.4 Boron-Based Materials

Boron-based 2D materials—including borophene and h-B₂O—exhibit unique electronic properties, including topological surface states and high carrier mobility, making them promising for high-temperature TE applications [(341)](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.739984/full).



* **Structure and Properties**: Borophene—a single layer of boron atoms—exhibits exceptional polymorphism, with different phases (e.g., β1s, α') exhibiting distinct electronic and phononic properties. For example, the β1s phase is a semiconductor with a direct band gap of \~1.5 eV, while the α' phase is metallic. h-B₂O—a honeycomb borophene oxide—exhibits strong anisotropy in electronic thermal conductivity (ETC), with room-temperature ETC values of \~5.9×10⁻² mW/mK along the yy direction and \~1.2×10⁻² mW/mK along the xx direction [(341)](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.739984/full).

* **Thermoelectric Performance**: Theoretical calculations predict that the β1s boron monolayer achieves a ZT of \~0.96 at room temperature for p-type carriers—among the highest values reported for single-layer light-element materials [(341)](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.739984/full). Chlorinated α'-borophene exhibits even higher performance, with a ZT of \~2.0 at 300 K along the armchair direction, attributed to ultra-low κ\_L (\~0.1 W/mK) and high carrier mobility.

* **Challenges**: Boron-based materials face significant synthesis challenges: β1s boron monolayers have not been synthesized in high quality, and borophene oxidizes in air within minutes [(267)](https://www.researchgate.net/publication/350901381_Progress_Challenges_and_Opportunities_in_the_Synthesis_Characterization_and_Application_of_Metal-Boride-Derived_Two-Dimensional_Nanostructures). These challenges must be addressed before boron-based materials can be used in practical TE devices.

## 5. Challenges and Future Perspectives

Despite significant progress, several critical challenges must be addressed to fully realize the potential of 2D material thermoelectrics for practical applications.

### 5.1 Material Stability

One of the most pressing challenges is the stability of 2D materials in ambient conditions. Air-sensitive materials like black phosphorus and borophene degrade rapidly when exposed to oxygen and moisture, limiting their practical utility. Even relatively stable materials like MoS₂ degrade at high temperatures in air, making them unsuitable for high-temperature TE applications.



* **Ambient Degradation**: Black phosphorus oxidizes in air within hours, with the Seebeck coefficient decreasing by \~50% in 48 hours [(268)](https://pmc.ncbi.nlm.nih.gov/articles/PMC7770910/). Borophene is even more sensitive, oxidizing in air within minutes.

* **High-Temperature Degradation**: MoS₂ degrades at 300°C in air, with the thermal conductivity decreasing by \~40% after 1 hour of annealing [(244)](https://pubmed.ncbi.nlm.nih.gov/35541259/). This limits its use in high-temperature TE applications (e.g., automotive waste heat recovery).

**Solutions**: Encapsulation with h-BN or other inert materials can significantly improve stability, but large-scale encapsulation of 2D materials remains challenging. The development of intrinsically stable 2D materials—such as h-B₂O, which exhibits high stability in air up to 500°C—offers another pathway forward [(244)](https://pubmed.ncbi.nlm.nih.gov/35541259/).

### 5.2 Scalable Synthesis

The synthesis of high-quality 2D materials with controlled thickness and large lateral size remains a major challenge. Most current synthesis methods—including mechanical exfoliation and CVD—are either low-yield or produce materials with inconsistent properties, making them unsuitable for industrial applications.



* **Mechanical Exfoliation**: This method produces high-quality 2D flakes but has a yield of <1% and produces flakes with uncontrollable size and thickness [(268)](https://pmc.ncbi.nlm.nih.gov/articles/PMC7770910/). It is therefore limited to laboratory research.

* **CVD**: CVD can produce large-area 2D materials, but the thickness and crystallinity are often inconsistent across the substrate. For example, CVD-grown MoS₂ monolayers have a thickness variation of \~0.5 nm across a 4-inch wafer, leading to variations in TE performance of \~20% [(274)](https://www.mpi-halle.mpg.de/857946/2026-01-27-rn-smfd?print=yes).

**Solutions**: The development of scalable synthesis methods—such as the GLS method for MXenes, which produces large-area, high-quality Ti₃C₂Cl₂ flakes with consistent thickness—offers promise for industrial applications [(274)](https://www.mpi-halle.mpg.de/857946/2026-01-27-rn-smfd?print=yes). Similarly, roll-to-roll CVD processes are being developed for large-scale synthesis of TMDs and phosphorene.

### 5.3 Characterization Techniques

Accurate characterization of thermal transport properties in 2D materials is challenging due to their atomic-scale thickness and high thermal resistance at interfaces. Conventional techniques—such as the 3ω method—are not always suitable for 2D materials, as they require a bulk substrate and can be affected by interface thermal resistance.



* **Thermal Conductivity Measurement**: The 3ω method is widely used for bulk materials but has limited accuracy for 2D materials, with errors of up to 30% for monolayers [(150)](https://i6172786976o6f7267z.oszar.com/pdf/2302.00202).

* **Interface Thermal Resistance Measurement**: The TBC between 2D materials and substrates is critical for TE performance, but current measurement techniques—such as time-domain thermoreflectance (TDTR)—have limited spatial resolution and cannot measure TBC at the nanoscale [(122)](https://pubs.acs.org/doi/abs/10.1021/acsami.1c24488).

**Solutions**: The development of advanced characterization techniques—such as scanning thermal microscopy (SThM) with nanoscale resolution and pump-probe techniques—offers promise for accurate measurement of thermal transport properties in 2D materials [(150)](https://i6172786976o6f7267z.oszar.com/pdf/2302.00202). These techniques can measure thermal conductivity and TBC with spatial resolution down to 10 nm, enabling the study of interface effects at the atomic scale.

### 5.4 Theoretical Understanding

While significant progress has been made in understanding transport in 2D materials, several key questions remain unanswered. The role of four-phonon scattering in 2D systems—particularly its contribution to κ\_L in low-dimensional materials—is not well understood, and the development of accurate models for electron-phonon coupling in 2D materials is still in its early stages.



* **Four-Phonon Scattering**: First-principles calculations for single-layer g-SbC show that four-phonon scattering contributes \~30% of the total lattice thermal resistance at room temperature, but the effect of this scattering mechanism on TE performance is not well quantified [(165)](https://pubs.rsc.org/en/content/articlepdf/2025/nr/d5nr02299a).

* **Electron-Phonon Coupling**: The electron-phonon coupling constant in 2D materials is typically larger than in bulk materials, but its effect on the Seebeck coefficient and electrical conductivity is not well understood. For example, in MoS₂, electron-phonon coupling enhances the Seebeck coefficient by \~10% but reduces the electrical conductivity by \~20%—creating a trade-off that is not yet fully modeled [(111)](https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790).

**Solutions**: The development of advanced theoretical models—including machine learning-based BTE solvers and ab initio molecular dynamics simulations—will be essential for understanding these complex transport mechanisms and designing high-performance 2D TE materials [(111)](https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790).

### 5.5 Future Directions

Despite these challenges, the field of 2D material thermoelectrics is poised for significant growth in the coming years. Several emerging research directions offer promise for overcoming current limitations and translating fundamental research into practical applications:



1. **Topological Thermoelectrics**: The integration of topological insulators and Weyl semimetals into TE devices could lead to unprecedented performance, as these materials exhibit high carrier mobility and large Seebeck coefficients. For example, BiSbTe alloys with topological surface states achieve a ZT of \~1.8 at room temperature—nearly twice the value of conventional BiSbTe [(154)](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c03871).

2. **Machine Learning**: Machine learning can be used to accelerate the discovery of new 2D TE materials and optimize interface engineering strategies. For example, a recent study used machine learning to identify over 100 promising 2D TE materials from a database of \~10,000 candidates—including several materials with predicted ZT values > 2.0 [(111)](https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790).

3. **Flexible Thermoelectrics**: The development of flexible TE devices for wearable electronics and automotive applications is a major area of research. 2D materials—with their high mechanical flexibility and low thermal conductivity—are ideal for these applications. For example, Ti₃C₂Tₓ/PVDF composites achieve a ZT of \~0.2 at 300 K and can withstand bending to a radius of \~1 cm without significant degradation [(329)](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/).

4. **Hybrid Systems**: The integration of 2D materials with bulk TE materials could lead to enhanced performance. For example, Bi₂Te₃ thin films with a 2D MoS₂ capping layer achieve a ZT of \~1.5 at room temperature—20% higher than pure Bi₂Te₃ films [(66)](https://www.jim.org.cn/CN/10.15541/jim20220736). The MoS₂ layer acts as a barrier to oxidation and enhances the Seebeck coefficient via energy filtering.

## 6. Summary

Two-dimensional materials represent a transformative platform for next-generation thermoelectric cooling and energy harvesting, offering the potential to overcome the long-standing challenges of bulk TE materials. By virtue of their atomic-scale thickness and inherently low lattice thermal conductivity, 2D materials enable the decoupling of electron and phonon transport—a critical breakthrough for achieving high ZT values.

This review has provided a comprehensive overview of the field, from the fundamental physical mechanisms governing transport in 2D systems to the latest interface engineering strategies and emerging material systems. Key insights include:



* **Quantum Confinement**: 2D confinement enhances the Seebeck coefficient by concentrating electronic states near the Fermi level, with thickness-dependent effects observed in systems like PdPS and WSe₂.

* **Interface Engineering**: van der Waals heterostructures, defect engineering, and substrate interactions provide powerful tools for tuning transport properties, with experimental breakthroughs including ZT values > 3.0 in twisted bilayer PdSe₂ and Janus PtTeSe.

* **Emerging Materials**: MXenes, TMDs, black phosphorus, and boron-based materials exhibit unique properties that can be tailored for TE applications, with composites and alloyed systems showing particular promise for high performance.

While significant challenges remain—including material stability, scalable synthesis, and accurate characterization—the field is advancing rapidly, with new breakthroughs reported regularly. The integration of topological physics, machine learning, and flexible device design offers exciting opportunities for the future, and it is clear that 2D materials will play a central role in the next generation of thermal management technologies.

**参考资料&#x20;**

\[1] 热电材料文献日报[ https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html](https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html)

\[2] Phase interface engineering enables state-of-the-art half-Heusler thermoelectrics[ https://pmc.ncbi.nlm.nih.gov/articles/PMC11252142/pdf/41467\_2024\_Article\_50371.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC11252142/pdf/41467_2024_Article_50371.pdf)

\[3] Enhancing Thermoelectric Efficiency in Twisted Bilayer PdSe 2[ https://pubs.acs.org/doi/10.1021/acsaem.4c01336](https://pubs.acs.org/doi/10.1021/acsaem.4c01336)

\[4] Synergistic optimization of the thermoelectric properties of the 2D MgI 2/Bi 2 S 3 heterostructure via  biaxial strain[ https://pubs.rsc.org/en/content/articlelanding/2026/cp/d6cp00188b](https://pubs.rsc.org/en/content/articlelanding/2026/cp/d6cp00188b)

\[5] Interfacial State Modulation toward High-Performance n-Type Bi2Te2.7Se0.3 Thermoelectric Material - PubMed[ https://pubmed.ncbi.nlm.nih.gov/40844984/](https://pubmed.ncbi.nlm.nih.gov/40844984/)

\[6] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[7] Recent Progress of Two-Dimensional Thermoelectric Materials - PubMed[ https://www.ncbi.nlm.nih.gov/pubmed/34138247](https://www.ncbi.nlm.nih.gov/pubmed/34138247)

\[8] Highly In-Plane Anisotropic 2D-ZrGeTe 4 : A Promising Thermoelectric Material with a High Power Factor and Figure of Merit[ https://pubs.acs.org/doi/pdf/10.1021/acsaem.5c00023](https://pubs.acs.org/doi/pdf/10.1021/acsaem.5c00023)

\[9] High Thermoelectric Performance in 2D Sb2Te3 and Bi2Te3 Nanoplate Composites Enabled by Energy Carrier Filtering and Low Thermal Conductivity - PubMed[ https://pubmed.ncbi.nlm.nih.gov/38828036/](https://pubmed.ncbi.nlm.nih.gov/38828036/)

\[10] From synthesis to device: comparative study of Bi 2 Te 3 alloys prepared by direct melt and ball milling for printed thermoelectrics[ https://pubs.rsc.org/en/content/articlehtml/2026/ya/d5ya00312a](https://pubs.rsc.org/en/content/articlehtml/2026/ya/d5ya00312a)

\[11] High Thermoelectric Performance of Few-Quintuple Sb 2 Te 3 Nanofilms[ https://www.researchgate.net/publication/321238782\_High\_Thermoelectric\_Performance\_of\_Few-Quintuple\_Sb\_2\_Te\_3\_Nanofilms](https://www.researchgate.net/publication/321238782_High_Thermoelectric_Performance_of_Few-Quintuple_Sb_2_Te_3_Nanofilms)

\[12] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[13] New Directions for Thermoelectrics: A Roadmap from High-Throughput Materials Discovery to Advanced Device Manufacturing[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12245080/pdf/SMSC-5-2300359.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12245080/pdf/SMSC-5-2300359.pdf)

\[14] Application of Thermoelectric Cooling on Chip Thermal Management[ https://m.researching.cn/articles/OJf2e99acda6cf7634](https://m.researching.cn/articles/OJf2e99acda6cf7634)

\[15] Thermoelectric Coolers for High-power-density 3D Electronics Heat Management[ https://pubs.aip.org/aip/apl/article-pdf/doi/10.1063/5.0088129/16448078/164101\_1\_accepted\_manuscript.pdf](https://pubs.aip.org/aip/apl/article-pdf/doi/10.1063/5.0088129/16448078/164101_1_accepted_manuscript.pdf)

\[16] Phonon and electron transport engineering for enhanced thermoelectric performance and the challenges of device integration[ https://www.oaepublish.com/articles/energymater.2025.32](https://www.oaepublish.com/articles/energymater.2025.32)

\[17] General strategy for developing thick-film micro-thermoelectric coolers from material fabrication to device integration[ https://pmc.ncbi.nlm.nih.gov/articles/PMC11079074/](https://pmc.ncbi.nlm.nih.gov/articles/PMC11079074/)

\[18] 2026年半导体封装散热材料创新报告.docx-原创力文档[ https://m.book118.com/html/2026/0309/5201012000013132.shtm](https://m.book118.com/html/2026/0309/5201012000013132.shtm)

\[19] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[20] Micro Thermoelectric Coolers: From Academic Breakthrough to Practical Thermal Management in Data Centers and Beyond[ https://www.zjcxtech.com/micro-thermoelectric-coolers-from-academic-breakthrough-to-practical-thermal-management-in-data-centers-and-beyond/](https://www.zjcxtech.com/micro-thermoelectric-coolers-from-academic-breakthrough-to-practical-thermal-management-in-data-centers-and-beyond/)

\[21] Thermoelectric active cooling for transient hot spots in microprocessors[ https://pmc.ncbi.nlm.nih.gov/articles/PMC11106063/pdf/41467\_2024\_Article\_48583.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC11106063/pdf/41467_2024_Article_48583.pdf)

\[22] Bismuth Telluride Bi2Te3 - Material Information[ https://www.goodfellow.com/de/resources/bismuth-telluride-bi2te3-material-information/](https://www.goodfellow.com/de/resources/bismuth-telluride-bi2te3-material-information/)

\[23] 我国学者在MgAgSb基热电器件研究方面取得进展[ https://www.nsfc.gov.cn/p1/3381/2825/79297.html](https://www.nsfc.gov.cn/p1/3381/2825/79297.html)

\[24] Interfacial State Modulation toward High-Performance n-Type Bi 2 Te 2.7 Se 0.3 Thermoelectric Material[ https://pubs.acs.org/doi/pdf/10.1021/acsami.5c12988](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c12988)

\[25] Enhanced Thermoelectric Performance of PEDOT/PSS by Interface Regulation of Hydroxylated Fluorinated Graphene[ https://pubs.acs.org/doi/abs/10.1021/acsapm.4c04184](https://pubs.acs.org/doi/abs/10.1021/acsapm.4c04184)

\[26] Phase interface engineering enables state-of-the-art half-Heusler thermoelectrics[ https://pubmed.ncbi.nlm.nih.gov/39013905/](https://pubmed.ncbi.nlm.nih.gov/39013905/)

\[27] Publications[ https://www.2dmatters.com/publications](https://www.2dmatters.com/publications)

\[28] Low-dimensional thermoelectric materials[ https://www.researchgate.net/publication/227336239\_Low-dimensional\_thermoelectric\_materials](https://www.researchgate.net/publication/227336239_Low-dimensional_thermoelectric_materials)

\[29] Recent Progress of Two-Dimensional Transition Metal Dichalcogenides for Thermoelectric Applications[ https://www.researchgate.net/publication/359163805\_Recent\_Progress\_of\_Two-Dimensional\_Transition\_Metal\_Dichalcogenides\_for\_Thermoelectric\_Applications](https://www.researchgate.net/publication/359163805_Recent_Progress_of_Two-Dimensional_Transition_Metal_Dichalcogenides_for_Thermoelectric_Applications)

\[30] Promising Thermoelectric Performance of Janus Monolayer ZrBrI[ https://www.mdpi.com/1996-1944/19/9/1716](https://www.mdpi.com/1996-1944/19/9/1716)

\[31] Enhanced Thermoelectric Performance of Nanostructured 2D Tin Telluride[ https://pubmed.ncbi.nlm.nih.gov/38873904/](https://pubmed.ncbi.nlm.nih.gov/38873904/)

\[32] Recent progress in thermoelectric MXene-based structures versus other 2D materials[ https://arxiv.org/pdf/2304.07015v2.pdf](https://arxiv.org/pdf/2304.07015v2.pdf)

\[33] High Thermoelectric Performance and Low Lattice Thermal Conductivity in 2D Topological Insulators MBiH (M = Ga, In): A First-Principles Study[ https://pubs.acs.org/doi/abs/10.1021/acsanm.5c01938](https://pubs.acs.org/doi/abs/10.1021/acsanm.5c01938)

\[34] Flexible Two-Dimensional Inorganic Nanosheet/PEDOT:PSS Thermoelectric Composite Films[ https://www.science.org/doi/full/10.34133/energymatadv.0097](https://www.science.org/doi/full/10.34133/energymatadv.0097)

\[35] Thermoelectric materials by using two-dimensional materials with negative correlation between electrical and thermal conductivity[ https://www.researchgate.net/publication/304216489\_Thermoelectric\_materials\_by\_using\_two-dimensional\_materials\_with\_negative\_correlation\_between\_electrical\_and\_thermal\_conductivity](https://www.researchgate.net/publication/304216489_Thermoelectric_materials_by_using_two-dimensional_materials_with_negative_correlation_between_electrical_and_thermal_conductivity)

\[36] Atomic Interface Engineering in Two-Dimensional Materials: A Pathway to High-Performance Flexible Thermoelectrics[ https://onlinelibrary.wiley.com/doi/10.1002/tcr.70160](https://onlinelibrary.wiley.com/doi/10.1002/tcr.70160)

\[37] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[38] Interfacial State Modulation toward High-Performance n-Type Bi 2 Te 2.7 Se 0.3 Thermoelectric Material[ https://pubs.acs.org/doi/pdf/10.1021/acsami.5c12988](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c12988)

\[39] 2D BiTe/Si heterostructure with high thermoelectric power factor enabled by interface regulated carrier injection[ https://pubmed.ncbi.nlm.nih.gov/36944227/](https://pubmed.ncbi.nlm.nih.gov/36944227/)

\[40] Incorporation of MXene into Bi 2 S 3 Matrix Promotes Better Electron Transport and Enhanced Thermoelectric Figure of Merit[ https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651](https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651)

\[41] Enhanced Thermoelectric Performance of PEDOT/PSS by Interface Regulation of Hydroxylated Fluorinated Graphene[ https://pubs.acs.org/doi/abs/10.1021/acsapm.4c04184](https://pubs.acs.org/doi/abs/10.1021/acsapm.4c04184)

\[42] Interface Engineering of 2D Materials toward High-Temperature Electronic Devices[ https://advanced.onlinelibrary.wiley.com/doi/abs/10.1002/adma.202418439](https://advanced.onlinelibrary.wiley.com/doi/abs/10.1002/adma.202418439)

\[43] Thermoelectric active cooling for transient hot spots in microprocessors[ https://pmc.ncbi.nlm.nih.gov/articles/PMC11106063/pdf/41467\_2024\_Article\_48583.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC11106063/pdf/41467_2024_Article_48583.pdf)

\[44] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[45] On-Chip Micro Temperature Controllers Based on Freestanding Thermoelectric Nano Films for Low-Power Electronics[ https://files01.core.ac.uk/download/pdf/604298642.pdf](https://files01.core.ac.uk/download/pdf/604298642.pdf)

\[46] On-Chip Micro Temperature Controllers Based on Freestanding Thermoelectric Nano Films for Low-Power Electronics[ https://pmc.ncbi.nlm.nih.gov/articles/PMC10879069/pdf/40820\_2024\_Article\_1342.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC10879069/pdf/40820_2024_Article_1342.pdf)

\[47] Recent Progress of Two-Dimensional Transition Metal Dichalcogenides for Thermoelectric Applications[ https://www.researchgate.net/publication/359163805\_Recent\_Progress\_of\_Two-Dimensional\_Transition\_Metal\_Dichalcogenides\_for\_Thermoelectric\_Applications](https://www.researchgate.net/publication/359163805_Recent_Progress_of_Two-Dimensional_Transition_Metal_Dichalcogenides_for_Thermoelectric_Applications)

\[48] Advances in van der Waals thermoelectric materials: prospects and challenges[ https://pubs.rsc.org/zh-tw/content/articlepdf/2025/lf/d4lf00383g](https://pubs.rsc.org/zh-tw/content/articlepdf/2025/lf/d4lf00383g)

\[49] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[50] High Thermoelectric Performance and Low Lattice Thermal Conductivity in 2D Topological Insulators MBiH (M = Ga, In): A First-Principles Study[ https://pubs.acs.org/doi/abs/10.1021/acsanm.5c01938](https://pubs.acs.org/doi/abs/10.1021/acsanm.5c01938)

\[51] Thermoelectric properties of M 2 BS 2 (M = Ti, Zr, Hf) monolayers: An Ab initio study[ https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290)

\[52] Nanostructured Semiconductors for Flexible Thermoelectric Applications[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12735830/pdf/nanomaterials-15-01843.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12735830/pdf/nanomaterials-15-01843.pdf)

\[53] Promising Thermoelectric Performance of Janus Monolayer ZrBrI[ https://www.mdpi.com/1996-1944/19/9/1716](https://www.mdpi.com/1996-1944/19/9/1716)

\[54] 2D BiTe/Si heterostructure with high thermoelectric power factor enabled by interface regulated carrier injection[ https://pubmed.ncbi.nlm.nih.gov/36944227/](https://pubmed.ncbi.nlm.nih.gov/36944227/)

\[55] Interfacial State Modulation toward High-Performance n-Type Bi 2 Te 2.7 Se 0.3 Thermoelectric Material[ https://pubs.acs.org/doi/pdf/10.1021/acsami.5c12988](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c12988)

\[56] Advances in van der Waals thermoelectric materials: prospects and challenges[ https://pubs.rsc.org/en/content/articlehtml/2025/lf/d4lf00383g](https://pubs.rsc.org/en/content/articlehtml/2025/lf/d4lf00383g)

\[57] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[58] Incorporation of MXene into Bi 2 S 3 Matrix Promotes Better Electron Transport and Enhanced Thermoelectric Figure of Merit[ https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651](https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651)

\[59] Interface Engineering of 2D Materials toward High-Temperature Electronic Devices[ https://advanced.onlinelibrary.wiley.com/doi/abs/10.1002/adma.202418439](https://advanced.onlinelibrary.wiley.com/doi/abs/10.1002/adma.202418439)

\[60] Thermal Transport Characteristics of Wrinkle Interface in Ultraflexible MoSSe–WX 2 (X = S, Se) Heterostructure[ https://pubs.acs.org/doi/abs/10.1021/acsami.5c11058](https://pubs.acs.org/doi/abs/10.1021/acsami.5c11058)

\[61] Graphene Film for Multifunctional Graphene-Based Thermal Interface Material with Bidirectional High Thermal Conductivity[ https://onlinelibrary.wiley.com/doi/full/10.1002/sstr.202400652](https://onlinelibrary.wiley.com/doi/full/10.1002/sstr.202400652)

\[62] Optimizing the Reliability of Bi 2 Te 3 -Based Thermoelectric Generators with Asymmetric Structures under Large Temperature Difference[ https://pubs.acs.org/doi/10.1021/acsaelm.5c01475](https://pubs.acs.org/doi/10.1021/acsaelm.5c01475)

\[63] Micro Thermoelectric Generator Technology Landscape 2026[ https://www.patsnap.com/resources/blog/rd-blog/micro-thermoelectric-generator-2026-patsnap-eureka/](https://www.patsnap.com/resources/blog/rd-blog/micro-thermoelectric-generator-2026-patsnap-eureka/)

\[64] Roadmap for Power Generation of Industrial Hot Extruded BiTe-Based Thermoelectric Device in Real-World Heat Sources[ https://pubmed.ncbi.nlm.nih.gov/39531668/](https://pubmed.ncbi.nlm.nih.gov/39531668/)

\[65] Homo-layer flexible Bi 2 Te 3 -based films with high thermoelectric performance[ https://www.sciencemag.org/doi/abs/10.1126/sciadv.adz1019](https://www.sciencemag.org/doi/abs/10.1126/sciadv.adz1019)

\[66] Bi 2 Te 3 基热电材料的湿热稳定性研究[ https://www.jim.org.cn/CN/10.15541/jim20220736](https://www.jim.org.cn/CN/10.15541/jim20220736)

\[67] Coupled Vacancy and Phonon‐Scattering Engineering Drive Defect Evolution Toward Multifunctional High‐Performance Bi2Te3 Thermoelectrics[ https://www.researchgate.net/publication/404399590\_Coupled\_Vacancy\_and\_Phonon-Scattering\_Engineering\_Drive\_Defect\_Evolution\_Toward\_Multifunctional\_High-Performance\_Bi2Te3\_Thermoelectrics](https://www.researchgate.net/publication/404399590_Coupled_Vacancy_and_Phonon-Scattering_Engineering_Drive_Defect_Evolution_Toward_Multifunctional_High-Performance_Bi2Te3_Thermoelectrics)

\[68] 半导体材料的 “选择密码”:为什么是碲化铋?-CSDN博客[ https://blog.csdn.net/hejishanghai/article/details/155484529](https://blog.csdn.net/hejishanghai/article/details/155484529)

\[69] Micro Thermoelectric Coolers: From Academic Breakthrough to Practical Thermal Management in Data Centers and Beyond[ https://www.zjcxtech.com/micro-thermoelectric-coolers-from-academic-breakthrough-to-practical-thermal-management-in-data-centers-and-beyond/](https://www.zjcxtech.com/micro-thermoelectric-coolers-from-academic-breakthrough-to-practical-thermal-management-in-data-centers-and-beyond/)

\[70] Energy Filtering in Doping Modulated Nanoengineered Thermoelectric Materials: A Monte Carlo Simulation Approach[ https://pmc.ncbi.nlm.nih.gov/articles/PMC11278894/pdf/materials-17-03522.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC11278894/pdf/materials-17-03522.pdf)

\[71] Thermal transport in Ti₃C₂ MXene enhanced by hydrogen functionalization-induced symmetry reconstruction[ https://pubs.aip.org/aip/jap/article-pdf/doi/10.1063/5.0310379/20905392/065103\_1\_5.0310379.pdf](https://pubs.aip.org/aip/jap/article-pdf/doi/10.1063/5.0310379/20905392/065103_1_5.0310379.pdf)

\[72] The influence of phonon renormalization caused by temperature effect on thermal conductivity of 2D monolayer InSe[ https://pubs.aip.org/aip/jap/article-pdf/doi/10.1063/5.0280402/20757563/154302\_1\_5.0280402.pdf](https://pubs.aip.org/aip/jap/article-pdf/doi/10.1063/5.0280402/20757563/154302_1_5.0280402.pdf)

\[73] Phonon Dominated Thermal Transport in Metallic Niobium Diselenide from First Principles Calculations | MDPI[ https://www.mdpi.com/2079-4991/13/2/315](https://www.mdpi.com/2079-4991/13/2/315)

\[74] Ab-initio transport model to study the thermoelectric performance of MoS2, MoSe2, and WS2 monolayers by using Boltzmann transport equation[ https://www.researchgate.net/publication/380035133\_Ab-initio\_transport\_model\_to\_study\_the\_thermoelectric\_performance\_of\_MoS2\_MoSe2\_and\_WS2\_monolayers\_by\_using\_Boltzmann\_transport\_equation](https://www.researchgate.net/publication/380035133_Ab-initio_transport_model_to_study_the_thermoelectric_performance_of_MoS2_MoSe2_and_WS2_monolayers_by_using_Boltzmann_transport_equation)

\[75] Magneto-thermoelectricty of anisotropic two-dimensional materials[ https://arxiv.org/pdf/2407.15074](https://arxiv.org/pdf/2407.15074)

\[76] Charge and energy transport in graphene with smooth finite-range disorder[ https://arxiv.org/html/2602.17453v1](https://arxiv.org/html/2602.17453v1)

\[77] Advances in Topological Thermoelectrics: Harnessing Quantum Materials for Energy Applications[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12506620/pdf/ADMA-37-2506417.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12506620/pdf/ADMA-37-2506417.pdf)

\[78] Phonon and electron transport engineering for enhanced thermoelectric performance and the challenges of device integration[ https://jmijournal.com/articles/energymater.2025.32](https://jmijournal.com/articles/energymater.2025.32)

\[79] 探秘二维过渡金属硫族化合物:自旋与能谷交织下的热电输运理论解析.docx-原创力文档[ https://m.book118.com/html/2025/1213/7123104135011023.shtm](https://m.book118.com/html/2025/1213/7123104135011023.shtm)

\[80] Thermoelectric Optimization and Quantum-to-Classical Crossover in Gate-Controlled Two-Dimensional Semiconducting Nanojunctions[ https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790?ref=article\_openPDF](https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790?ref=article_openPDF)

\[81] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[82] Topology in thermoelectric materials[ https://www.researchgate.net/publication/394391125\_Topology\_in\_thermoelectric\_materials](https://www.researchgate.net/publication/394391125_Topology_in_thermoelectric_materials)

\[83] Synergy of Rashba and Topological Effects for High-Performance Bismuth-Based Thermoelectrics[ https://arxiv.org/html/2506.21479v1/](https://arxiv.org/html/2506.21479v1/)

\[84] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[85] 热电材料文献日报[ https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html](https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html)

\[86] Enhanced thermoelectric performance, inter-layer coupling effects and reduced lattice thermal conductivity in two-dimensional transition metal oxides[ https://pubs.rsc.org/en/content/articlepdf/2025/na/d5na00303b](https://pubs.rsc.org/en/content/articlepdf/2025/na/d5na00303b)

\[87] High-Temperature Thermoelectric Monolayer Bi 2 TeSe 2 with High Power Factor and Ultralow Thermal Conductivity[ https://www.researchgate.net/publication/358692015\_High-Temperature\_Thermoelectric\_Monolayer\_Bi\_2\_TeSe\_2\_with\_High\_Power\_Factor\_and\_Ultralow\_Thermal\_Conductivity](https://www.researchgate.net/publication/358692015_High-Temperature_Thermoelectric_Monolayer_Bi_2_TeSe_2_with_High_Power_Factor_and_Ultralow_Thermal_Conductivity)

\[88] Weak Polar Optical Phonon Scattering Decouples Electron and Phonon Transport in Layered Thermoelectric Materials[ https://arxiv.org/pdf/2604.23328](https://arxiv.org/pdf/2604.23328)

\[89] Nanostructured Semiconductors for Flexible Thermoelectric Applications[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12735830/pdf/nanomaterials-15-01843.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12735830/pdf/nanomaterials-15-01843.pdf)

\[90] Defect-tolerant electron and defect-sensitive phonon transport in quasi-2D conjugated coordination polymers[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12274412/pdf/41467\_2025\_Article\_61920.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12274412/pdf/41467_2025_Article_61920.pdf)

\[91] Thermoelectric transport properties of 2D semiconducting MXene Ti₂CO₂ with a large figure of merit[ https://aip.scitation.org/aip/jap/article-pdf/doi/10.1063/5.0267864/20560049/234302\_1\_5.0267864.pdf](https://aip.scitation.org/aip/jap/article-pdf/doi/10.1063/5.0267864/20560049/234302_1_5.0267864.pdf)

\[92] Recent Progress in Multiphase Thermoelectric Materials[ https://pmc.ncbi.nlm.nih.gov/articles/PMC8540781/](https://pmc.ncbi.nlm.nih.gov/articles/PMC8540781/)

\[93] Phonon Dominated Thermal Transport in Metallic Niobium Diselenide from First Principles Calculations | MDPI[ https://www.mdpi.com/2079-4991/13/2/315](https://www.mdpi.com/2079-4991/13/2/315)

\[94] Ab-initio transport model to study the thermoelectric performance of MoS2, MoSe2, and WS2 monolayers by using Boltzmann transport equation[ https://www.researchgate.net/publication/380035133\_Ab-initio\_transport\_model\_to\_study\_the\_thermoelectric\_performance\_of\_MoS2\_MoSe2\_and\_WS2\_monolayers\_by\_using\_Boltzmann\_transport\_equation](https://www.researchgate.net/publication/380035133_Ab-initio_transport_model_to_study_the_thermoelectric_performance_of_MoS2_MoSe2_and_WS2_monolayers_by_using_Boltzmann_transport_equation)

\[95] Magneto-thermoelectricty of anisotropic two-dimensional materials[ https://arxiv.org/pdf/2407.15074](https://arxiv.org/pdf/2407.15074)

\[96] Deciphering Cationic/Anionic Substitutions Decouple Phononic and Electronic Transport, Enabling High Thermoelectricity in Heterostructures[ https://pubs.acs.org/doi/pdf/10.1021/acsaem.5c02543](https://pubs.acs.org/doi/pdf/10.1021/acsaem.5c02543)

\[97] Enhanced Thermoelectric Properties of Phosphorene via Quantum Size Effects and Relaxation Time Tuning[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12156281/pdf/materials-18-02506.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12156281/pdf/materials-18-02506.pdf)

\[98] A novel two-dimensional thermoelectric material silicene with high ZT for both N-type and P-type doping at low carrier concentration[ http://cpl.iphy.ac.cn/en/article/pdf/preview/10.1088/0256-307X/42/12/120710.pdf](http://cpl.iphy.ac.cn/en/article/pdf/preview/10.1088/0256-307X/42/12/120710.pdf)

\[99] Thermoelectric Optimization and Quantum-to-Classical Crossover in Gate-Controlled Two-Dimensional Semiconducting Nanojunctions[ https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790?ref=article\_openPDF](https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790?ref=article_openPDF)

\[100] Excellent thermoelectric performance and impressive optoelectronic properties of Janus monolayer of ZrXY(X=O, S) (Y=S, Se)[ https://arxiv.org/pdf/2206.08997](https://arxiv.org/pdf/2206.08997)

\[101] Enhanced Thermoelectric Performance in 2D ZrX2N4 (X = Si, Ge) Monolayers: A First-Principles Study[ https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159](https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159)

\[102] Strain- and chirality-engineered tunability of electronic and thermoelectric properties in SiC nanotubes: insights from first-principles calculations[ https://pubs.rsc.org/en/content/articlehtml/2026/ra/d6ra00892e](https://pubs.rsc.org/en/content/articlehtml/2026/ra/d6ra00892e)

\[103] Enhancing Thermoelectric Efficiency in Twisted Bilayer PdSe 2[ https://pubs.acs.org/doi/10.1021/acsaem.4c01336](https://pubs.acs.org/doi/10.1021/acsaem.4c01336)

\[104] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[105] Moiré-Driven Interfacial Thermal Transport in Twisted Transition Metal Dichalcogenides - PubMed[ https://pubmed.ncbi.nlm.nih.gov/40264346/](https://pubmed.ncbi.nlm.nih.gov/40264346/)

\[106] Phase interface engineering enables state-of-the-art half-Heusler thermoelectrics[ https://pmc.ncbi.nlm.nih.gov/articles/PMC11252142/pdf/41467\_2024\_Article\_50371.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC11252142/pdf/41467_2024_Article_50371.pdf)

\[107] 二维材料热管理最佳分析 - 豆丁网[ https://www.docin.com/touch\_new/preview\_new.do?id=4893721767](https://www.docin.com/touch_new/preview_new.do?id=4893721767)

\[108] Interface-engineered melt-spun BiSbTe for multiscale phonon scattering and enhanced thermoelectric performance[ https://pubs.rsc.org/zh-hans/content/articlepdf/2026/ta/d5ta09730d](https://pubs.rsc.org/zh-hans/content/articlepdf/2026/ta/d5ta09730d)

\[109] Film Thermoelectric Generator of Multiple 2-D Electron Gas[ https://www.researchgate.net/publication/381677290\_Film\_Thermoelectric\_Generator\_of\_Multiple\_2-D\_Electron\_Gas](https://www.researchgate.net/publication/381677290_Film_Thermoelectric_Generator_of_Multiple_2-D_Electron_Gas)

\[110] Semiclassical Electron and Phonon Transport from First Principles: Application to Layered Thermoelectrics[ https://i6172786976o6f7267z.oszar.com/pdf/2302.00202](https://i6172786976o6f7267z.oszar.com/pdf/2302.00202)

\[111] Thermoelectric Optimization and Quantum-to-Classical Crossover in Gate-Controlled Two-Dimensional Semiconducting Nanojunctions[ https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790](https://pubs.acs.org/doi/pdf/10.1021/acsnano.5c10790)

\[112] 新型层状材料电输运性质及热电应用研究.pdf-原创力文档[ https://m.book118.com/html/2026/0203/5212113133013120.shtm](https://m.book118.com/html/2026/0203/5212113133013120.shtm)

\[113] Revisiting thermoelectric transport properties through a band nonparabolicity factor[ https://academic.oup.com/nsr/article/12/8/nwaf216/8154513](https://academic.oup.com/nsr/article/12/8/nwaf216/8154513)

\[114] Thermoelectric Optimization through Quantum–Classical Transport Crossover in WSe₂ Nanojunctions[ https://advanceseng.com/thermoelectric-optimization-through-quantum-classical-transport-crossover-in-wse%E2%82%82-nanojunctions/](https://advanceseng.com/thermoelectric-optimization-through-quantum-classical-transport-crossover-in-wse%E2%82%82-nanojunctions/)

\[115] Ultra-low thermal conductivity induced by significant anharmonic phonon scattering in two-dimensional graphitic metal (Sb and Bi) carbides[ https://pubs.rsc.org/en/content/articlepdf/2025/nr/d5nr02299a](https://pubs.rsc.org/en/content/articlepdf/2025/nr/d5nr02299a)

\[116] Electron-Phonon Interaction and Lattice Thermal Conductivity from Metals to 2D Dirac Crystals: A REVIEW[ https://arxiv.org/pdf/2508.18477v2](https://arxiv.org/pdf/2508.18477v2)

\[117] Impact of Four-Phonon Scattering on Thermal Transport and Thermoelectric Performance of Penta-XP₂ (X = Pd, Pt) Monolayers[ https://pdfs.semanticscholar.org/bbcb/1ab531e8227dd0e9b037f8b6e957c63571e0.pdf](https://pdfs.semanticscholar.org/bbcb/1ab531e8227dd0e9b037f8b6e957c63571e0.pdf)

\[118] Anomalous phonon thermal transport in boron chalcogenides: Role of four-phonon scattering[ https://www.me.iitb.ac.in/\~a\_jain/mypublications/JAP\_2025.pdf](https://www.me.iitb.ac.in/~a_jain/mypublications/JAP_2025.pdf)

\[119] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[120] Interface-engineered melt-spun BiSbTe for multiscale phonon scattering and enhanced thermoelectric performance[ https://pubs.rsc.org/zh-hans/content/articlepdf/2026/ta/d5ta09730d](https://pubs.rsc.org/zh-hans/content/articlepdf/2026/ta/d5ta09730d)

\[121] Thermoelectric properties of monolayer Cu2X[ https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.72.20222015?viewType=References](https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.72.20222015?viewType=References)

\[122] Four-Phonon Scattering Effect and Two-Channel Thermal Transport in Two-Dimensional Paraelectric SnSe[ https://pubs.acs.org/doi/abs/10.1021/acsami.1c24488](https://pubs.acs.org/doi/abs/10.1021/acsami.1c24488)

\[123] Ambipolar Thickness-Dependent Thermoelectric Measurements of WSe₂[ https://poplab.stanford.edu/pdfs/Chen-AmbipolarThermoelectricWSe2-nl23.pdf](https://poplab.stanford.edu/pdfs/Chen-AmbipolarThermoelectricWSe2-nl23.pdf)

\[124] Recent Progress of Two-Dimensional Transition Metal Dichalcogenides for Thermoelectric Applications[ https://www.researchgate.net/publication/359163805\_Recent\_Progress\_of\_Two-Dimensional\_Transition\_Metal\_Dichalcogenides\_for\_Thermoelectric\_Applications](https://www.researchgate.net/publication/359163805_Recent_Progress_of_Two-Dimensional_Transition_Metal_Dichalcogenides_for_Thermoelectric_Applications)

\[125] Thickness Dependence Electric and Thermoelectric Properties of Thermally Evaporated Nanostructured Bismuth Selenide Thin Films[ https://ijarsct.co.in/Paper15400.pdf](https://ijarsct.co.in/Paper15400.pdf)

\[126] Ambipolar Thickness-Dependent Thermoelectric Measurements of WSe2 - PubMed[ https://pubmed.ncbi.nlm.nih.gov/37141159/](https://pubmed.ncbi.nlm.nih.gov/37141159/)

\[127] Abnormal Seebeck Effect in Vertically Stacked 2D/2D PtSe/PtSeHomostructure[ https://pubmed.ncbi.nlm.nih.gov/36354191/](https://pubmed.ncbi.nlm.nih.gov/36354191/)

\[128] Thermoelectric materials by using two-dimensional materials with negative correlation between electrical and thermal conductivity[ https://typeset.io/pdf/thermoelectric-materials-by-using-two-dimensional-materials-5f98kpehum.pdf](https://typeset.io/pdf/thermoelectric-materials-by-using-two-dimensional-materials-5f98kpehum.pdf)

\[129] Semiclassical Electron and Phonon Transport from First Principles: Application to Layered Thermoelectrics[ https://arxiv.org/pdf/2302.00202v1](https://arxiv.org/pdf/2302.00202v1)

\[130] Thermal Transport in 2D Materials[ https://pmc.ncbi.nlm.nih.gov/articles/PMC9824888/](https://pmc.ncbi.nlm.nih.gov/articles/PMC9824888/)

\[131] 新型层状材料电输运性质及热电应用研究.pdf-原创力文档[ https://m.book118.com/html/2026/0203/5212113133013120.shtm](https://m.book118.com/html/2026/0203/5212113133013120.shtm)

\[132] A direct approach to calculate the temperature dependence of the electronic relaxation time in 2D semiconductors from Boltzmann transport theory[ https://www.researchgate.net/publication/359118615\_A\_direct\_approach\_to\_calculate\_the\_temperature\_dependence\_of\_the\_electronic\_relaxation\_time\_in\_2D\_semiconductors\_from\_Boltzmann\_transport\_theory](https://www.researchgate.net/publication/359118615_A_direct_approach_to_calculate_the_temperature_dependence_of_the_electronic_relaxation_time_in_2D_semiconductors_from_Boltzmann_transport_theory)

\[133] Phonon Dominated Thermal Transport in Metallic Niobium Diselenide from First Principles Calculations | MDPI[ https://www.mdpi.com/2079-4991/13/2/315](https://www.mdpi.com/2079-4991/13/2/315)

\[134] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[135] Thermoelectric transport properties of two-dimensional materials XTe2 (X = Pd, Pt) via first-principles calculations[ https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.70.20201939](https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.70.20201939)

\[136] A Bond-order Theory on the Phonon Scattering by Vacancies in Two-dimensional Materials[ https://pmc.ncbi.nlm.nih.gov/articles/PMC4035577/](https://pmc.ncbi.nlm.nih.gov/articles/PMC4035577/)

\[137] Phonon Scattering and Thermal Transport in PbSe and Medium Entropy Thermoelectric PbSe0.5Te0.25S0.25 with Defects of Different Dimensions - PubMed[ https://pubmed.ncbi.nlm.nih.gov/40405376/](https://pubmed.ncbi.nlm.nih.gov/40405376/)

\[138] Coupled Vacancy and Phonon-Scattering Engineering Drive Defect Evolution Toward Multifunctional High-Performance Bi 2 Te 3 Thermoelectrics[ https://advanced.onlinelibrary.wiley.com/doi/10.1002/advs.75529](https://advanced.onlinelibrary.wiley.com/doi/10.1002/advs.75529)

\[139] Promising Thermoelectric Performance of Janus Monolayer ZrBrI[ https://www.mdpi.com/1996-1944/19/9/1716](https://www.mdpi.com/1996-1944/19/9/1716)

\[140] Phonon Scattering and Thermal Transport in PbSe and Medium Entropy Thermoelectric PbSe 0.5 Te 0.25 S 0.25 with Defects of Different Dimensions[ https://pubs.acs.org/doi/pdf/10.1021/acs.jpclett.5c00740](https://pubs.acs.org/doi/pdf/10.1021/acs.jpclett.5c00740)

\[141] Unleashing the Impact of Topological Surface States on the Thermoelectric Properties of Granular Sb₂Te₃ Thin Films Deposited on Flexible Substrates[ https://pubs.acs.org/doi/pdf/10.1021/acsami.5c03871](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c03871)

\[142] Topological insulators for thermoelectrics: A perspective from beneath the surface[ https://pmc.ncbi.nlm.nih.gov/articles/PMC11910883/pdf/main.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC11910883/pdf/main.pdf)

\[143] Topology in thermoelectric materials[ https://www.researchgate.net/publication/394391125\_Topology\_in\_thermoelectric\_materials](https://www.researchgate.net/publication/394391125_Topology_in_thermoelectric_materials)

\[144] Extraordinary Thermoelectric Properties of Topological Surface States in Quantum-Confined Cd3As2 Thin Films - PubMed[ https://pubmed.ncbi.nlm.nih.gov/38684220/](https://pubmed.ncbi.nlm.nih.gov/38684220/)

\[145] Thermopower in HgTe-based topological insulators and two-dimensional semimetals[ http://romeo.if.usp.br/\~gusev/UFNThermo.pdf](http://romeo.if.usp.br/~gusev/UFNThermo.pdf)

\[146] Synergy of Rashba and Topological Effects for High-Performance Bismuth-Based Thermoelectrics[ https://arxiv.org/html/2506.21479v1/](https://arxiv.org/html/2506.21479v1/)

\[147] Topological materials for thermoelectric energy conversion[ https://www.cpfs.mpg.de/3474955/ssc\_02.pdf](https://www.cpfs.mpg.de/3474955/ssc_02.pdf)

\[148] A direct approach to calculate the temperature dependence of the electronic relaxation time in 2D semiconductors from Boltzmann transport theory[ https://www.researchgate.net/publication/359118615\_A\_direct\_approach\_to\_calculate\_the\_temperature\_dependence\_of\_the\_electronic\_relaxation\_time\_in\_2D\_semiconductors\_from\_Boltzmann\_transport\_theory](https://www.researchgate.net/publication/359118615_A_direct_approach_to_calculate_the_temperature_dependence_of_the_electronic_relaxation_time_in_2D_semiconductors_from_Boltzmann_transport_theory)

\[149] 新型层状材料电输运性质及热电应用研究.pdf-原创力文档[ https://m.book118.com/html/2026/0203/5212113133013120.shtm](https://m.book118.com/html/2026/0203/5212113133013120.shtm)

\[150] Semiclassical Electron and Phonon Transport from First Principles: Application to Layered Thermoelectrics[ https://i6172786976o6f7267z.oszar.com/pdf/2302.00202](https://i6172786976o6f7267z.oszar.com/pdf/2302.00202)

\[151] Thermal Transport in 2D Materials[ https://pmc.ncbi.nlm.nih.gov/articles/PMC9824888/](https://pmc.ncbi.nlm.nih.gov/articles/PMC9824888/)

\[152] Phonon Dominated Thermal Transport in Metallic Niobium Diselenide from First Principles Calculations | MDPI[ https://www.mdpi.com/2079-4991/13/2/315](https://www.mdpi.com/2079-4991/13/2/315)

\[153] Methods for Measuring Thermal Conductivity of Two-Dimensional Materials: A Review[ https://pmc.ncbi.nlm.nih.gov/articles/PMC8877908/](https://pmc.ncbi.nlm.nih.gov/articles/PMC8877908/)

\[154] Unleashing the Impact of Topological Surface States on the Thermoelectric Properties of Granular Sb₂Te₃ Thin Films Deposited on Flexible Substrates[ https://pubs.acs.org/doi/pdf/10.1021/acsami.5c03871](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c03871)

\[155] Thermopower in HgTe-based topological insulators and two-dimensional semimetals[ http://romeo.if.usp.br/\~gusev/UFNThermo.pdf](http://romeo.if.usp.br/~gusev/UFNThermo.pdf)

\[156] Topology in thermoelectric materials[ https://www.researchgate.net/publication/394391125\_Topology\_in\_thermoelectric\_materials](https://www.researchgate.net/publication/394391125_Topology_in_thermoelectric_materials)

\[157] Thermoelectric effects and topological insulators[ https://cpb.iphy.ac.cn/article/2016/1857/cpb\_25\_11\_117309.html](https://cpb.iphy.ac.cn/article/2016/1857/cpb_25_11_117309.html)

\[158] Unleashing the Impact of Topological Surface States on the Thermoelectric Properties of Granular Sb 2 Te 3 Thin Films Deposited on Flexible Substrates[ https://doi.org/10.1021/acsami.5c03871](https://doi.org/10.1021/acsami.5c03871)

\[159] Topological Insulators for Thermoelectrics: A Perspective from Beneath the Surface[ https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2024-zpmpp](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2024-zpmpp)

\[160] Topological insulators for thermoelectrics: A perspective from beneath the surface - PMC[ https://pmc.ncbi.nlm.nih.gov/articles/PMC11910883/](https://pmc.ncbi.nlm.nih.gov/articles/PMC11910883/)

\[161] Unleashing the Impact of Topological Surface States on the Thermoelectric Properties of Granular Sb2Te3 Thin Films Deposited on Flexible Substrates - PMC[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12203476/](https://pmc.ncbi.nlm.nih.gov/articles/PMC12203476/)

\[162] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[163] Thermoelectric transport properties of two-dimensional materials XTe2 (X = Pd, Pt) via first-principles calculations[ https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.70.20201939](https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.70.20201939)

\[164] Coupled Vacancy and Phonon‐Scattering Engineering Drive Defect Evolution Toward Multifunctional High‐Performance Bi2Te3 Thermoelectrics[ https://www.researchgate.net/publication/404399590\_Coupled\_Vacancy\_and\_Phonon-Scattering\_Engineering\_Drive\_Defect\_Evolution\_Toward\_Multifunctional\_High-Performance\_Bi2Te3\_Thermoelectrics](https://www.researchgate.net/publication/404399590_Coupled_Vacancy_and_Phonon-Scattering_Engineering_Drive_Defect_Evolution_Toward_Multifunctional_High-Performance_Bi2Te3_Thermoelectrics)

\[165] Ultra-low thermal conductivity induced by significant anharmonic phonon scattering in two-dimensional graphitic metal (Sb and Bi) carbides[ https://pubs.rsc.org/en/content/articlepdf/2025/nr/d5nr02299a](https://pubs.rsc.org/en/content/articlepdf/2025/nr/d5nr02299a)

\[166] Promising Thermoelectric Performance of Janus Monolayer ZrBrI[ https://www.mdpi.com/1996-1944/19/9/1716](https://www.mdpi.com/1996-1944/19/9/1716)

\[167] Nanostructured Semiconductors for Flexible Thermoelectric Applications[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12735830/pdf/nanomaterials-15-01843.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12735830/pdf/nanomaterials-15-01843.pdf)

\[168] Thermoelectric properties of monolayer Cu2X[ https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.72.20222015?viewType=References](https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.72.20222015?viewType=References)

\[169] Modulating Thermoelectric Properties of the MoSe2/WSe2 Superlattice Heterostructure by Twist Angles - PubMed[ https://pubmed.ncbi.nlm.nih.gov/38190725/](https://pubmed.ncbi.nlm.nih.gov/38190725/)

\[170] Enhanced thermoelectric performance, inter-layer coupling effects and reduced lattice thermal conductivity in two-dimensional transition metal oxides[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12451456/pdf/NA-007-D5NA00303B.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12451456/pdf/NA-007-D5NA00303B.pdf)

\[171] Toward the Thermoelectric ZT Limit via the Quantification of Interface-Driven Carrier Sorting[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12444869/pdf/SMLL-21-e05325.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12444869/pdf/SMLL-21-e05325.pdf)

\[172] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[173] Strain Effect on Rashba Splitting and Phonon Scattering to Improve Thermoelectric Performance of 2D Heterobilayer MoTe 2/PtS 2[ https://pubs.acs.org/doi/abs/10.1021/acsaem.5c01254](https://pubs.acs.org/doi/abs/10.1021/acsaem.5c01254)

\[174] Large enhancement of thermoelectric performance in MoS/-BN heterostructure due to vacancy-induced band hybridization[ https://pubmed.ncbi.nlm.nih.gov/32522877/](https://pubmed.ncbi.nlm.nih.gov/32522877/)

\[175] Thermal Transport Characteristics of Wrinkle Interface in Ultraflexible MoSSe–WX 2 (X = S, Se) Heterostructure[ https://pubs.acs.org/doi/abs/10.1021/acsami.5c11058](https://pubs.acs.org/doi/abs/10.1021/acsami.5c11058)

\[176] Coupled Vacancy and Phonon-Scattering Engineering Drive Defect Evolution Toward Multifunctional High-Performance Bi 2 Te 3 Thermoelectrics[ https://advanced.onlinelibrary.wiley.com/doi/10.1002/advs.75529](https://advanced.onlinelibrary.wiley.com/doi/10.1002/advs.75529)

\[177] Synergistic Bi–Te Antisite Defects and Crystalline-Amorphous Hybrid Structure Enable Record-High Thermoelectric Performance in Flexible Bi 2 Te 2.7 Se 0.3 Films[ https://advanced.onlinelibrary.wiley.com/doi/10.1002/aenm.71038](https://advanced.onlinelibrary.wiley.com/doi/10.1002/aenm.71038)

\[178] Defect Engineering Boosted Ultrahigh Thermoelectric Power Conversion Efficiency in Polycrystalline SnSe[ https://pubs.acs.org/doi/pdf/10.1021/acsami.1c18194](https://pubs.acs.org/doi/pdf/10.1021/acsami.1c18194)

\[179] デュアル欠陥工学戦略によりN型熱電薄膜の性能を向上（Dual-Defect Engineering Strategy Boosts N-Type Thermoelectric Thin Film Performance）[ https://tiisys.com/blog/2026/03/04/post-187009/](https://tiisys.com/blog/2026/03/04/post-187009/)

\[180] Defects Engineering with Multiple Dimensions in Thermoelectric Materials[ https://pmc.ncbi.nlm.nih.gov/articles/PMC7261317/](https://pmc.ncbi.nlm.nih.gov/articles/PMC7261317/)

\[181] 热电转换器件封装.docx-原创力文档[ https://m.book118.com/html/2026/0107/8016024116010032.shtm](https://m.book118.com/html/2026/0107/8016024116010032.shtm)

\[182] Enhanced Thermal Management in Microelectronics Packaging With 2D h-BN Nanocomposite Underfills[ https://onlinelibrary.wiley.com/doi/full/10.1002/nano.202400073](https://onlinelibrary.wiley.com/doi/full/10.1002/nano.202400073)

\[183] Excellent Stability of n -Type Thermoelectric Thin Films Using Cationic Surfactant/Single-Walled Carbon Nanotube Composites[ https://pubs.acs.org/doi/abs/10.1021/acsaelm.6c00189](https://pubs.acs.org/doi/abs/10.1021/acsaelm.6c00189)

\[184] Quasi-Monolithic All-in-One TEG-PCM Systems: Reducing Thermal Interfaces via Multilayer PCB Technology[ https://www.mdpi.com/2076-0825/15/5/239](https://www.mdpi.com/2076-0825/15/5/239)

\[185] All-solution-processed scalable and wearable organic thermoelectrics by structurally mimicking transverse thermoelectric effects[ https://www.science.org/doi/full/10.1126/sciadv.aea9094](https://www.science.org/doi/full/10.1126/sciadv.aea9094)

\[186] Enhanced thermoelectric performance, inter-layer coupling effects and reduced lattice thermal conductivity in two-dimensional transition metal oxides[ https://pubs.rsc.org/en/content/articlepdf/2025/na/d5na00303b](https://pubs.rsc.org/en/content/articlepdf/2025/na/d5na00303b)

\[187] Thermal transport in graphene under large mechanical strains[ https://pubs.aip.org/aip/jap/article-pdf/doi/10.1063/5.0223188/20115671/074302\_1\_5.0223188.pdf](https://pubs.aip.org/aip/jap/article-pdf/doi/10.1063/5.0223188/20115671/074302_1_5.0223188.pdf)

\[188] Advances in van der Waals thermoelectric materials: prospects and challenges[ https://pubs.rsc.org/en/content/articlehtml/2025/lf/d4lf00383g](https://pubs.rsc.org/en/content/articlehtml/2025/lf/d4lf00383g)

\[189] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[190] Enhanced thermoelectric performance, inter-layer coupling effects and reduced lattice thermal conductivity in two-dimensional transition metal oxides[ https://pubs.rsc.org/en/content/articlepdf/2025/na/d5na00303b](https://pubs.rsc.org/en/content/articlepdf/2025/na/d5na00303b)

\[191] 热电材料文献日报[ https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html](https://cmpdc.iphy.ac.cn/literature/dailyread/%E7%83%AD%E7%94%B5%E6%9D%90%E6%96%99.html)

\[192] Nanostructured Semiconductors for Flexible Thermoelectric Applications[ https://pdfs.semanticscholar.org/93c4/141ff206135bbee1990f069d4bed63ad4f0c.pdf](https://pdfs.semanticscholar.org/93c4/141ff206135bbee1990f069d4bed63ad4f0c.pdf)

\[193] Coupling Heat And Electricity: Exceptional Thermoelectric Properties Of Single Van Der Waal's Junction In Twisted Bilayer Graphene[ https://gyti.techpedia.in/project-detail/coupling-heat-and-electricity-exceptional-thermoelectric-properties-of-single-van/11873](https://gyti.techpedia.in/project-detail/coupling-heat-and-electricity-exceptional-thermoelectric-properties-of-single-van/11873)

\[194] Enhanced thermoelectric performance of van der Waals Tellurium via vacancy engineering[ https://zlab.nju.edu.cn/\_upload/article/files/61/da/cbc841434728a48b712c84c821ab/f9ddec2b-84d3-4108-8650-00d9883d963c.pdf](https://zlab.nju.edu.cn/_upload/article/files/61/da/cbc841434728a48b712c84c821ab/f9ddec2b-84d3-4108-8650-00d9883d963c.pdf)

\[195] Recent Progress of Two-Dimensional Transition Metal Dichalcogenides for Thermoelectric Applications[ https://www.researchgate.net/publication/359163805\_Recent\_Progress\_of\_Two-Dimensional\_Transition\_Metal\_Dichalcogenides\_for\_Thermoelectric\_Applications](https://www.researchgate.net/publication/359163805_Recent_Progress_of_Two-Dimensional_Transition_Metal_Dichalcogenides_for_Thermoelectric_Applications)

\[196] Large enhancement of thermoelectric performance in MoS/-BN heterostructure due to vacancy-induced band hybridization[ https://pubmed.ncbi.nlm.nih.gov/32522877/](https://pubmed.ncbi.nlm.nih.gov/32522877/)

\[197] Defect-Energy-Targeted Lattice Repair Delivers High Thermoelectric Performance in Magnesium Antimonide[ https://pubs.acs.org/doi/10.1021/jacs.6c02279](https://pubs.acs.org/doi/10.1021/jacs.6c02279)

\[198] Coupled Vacancy and Phonon‐Scattering Engineering Drive Defect Evolution Toward Multifunctional High‐Performance Bi2Te3 Thermoelectrics[ https://www.researchgate.net/publication/404399590\_Coupled\_Vacancy\_and\_Phonon-Scattering\_Engineering\_Drive\_Defect\_Evolution\_Toward\_Multifunctional\_High-Performance\_Bi2Te3\_Thermoelectrics](https://www.researchgate.net/publication/404399590_Coupled_Vacancy_and_Phonon-Scattering_Engineering_Drive_Defect_Evolution_Toward_Multifunctional_High-Performance_Bi2Te3_Thermoelectrics)

\[199] Enhanced thermoelectric performance, inter-layer coupling effects and reduced lattice thermal conductivity in two-dimensional transition metal oxides[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12451456/pdf/NA-007-D5NA00303B.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12451456/pdf/NA-007-D5NA00303B.pdf)

\[200] Strain Effect on Rashba Splitting and Phonon Scattering to Improve Thermoelectric Performance of 2D Heterobilayer MoTe₂/PtS₂[ https://pubs.acs.org/doi/pdf/10.1021/acsaem.5c01254](https://pubs.acs.org/doi/pdf/10.1021/acsaem.5c01254)

\[201] Van der Waals interlayer coupling effect on the transport and thermoelectric properties of SnX (X=S or Se) bilayers and heterostructure[ https://pubs.acs.org/doi/suppl/10.1021/acsaem.0c01020/suppl\_file/ae0c01020\_si\_001.pdf](https://pubs.acs.org/doi/suppl/10.1021/acsaem.0c01020/suppl_file/ae0c01020_si_001.pdf)

\[202] Thermal Transport in Two-Dimensional Heterostructures[ https://www.frontiersin.org/journals/materials/articles/10.3389/fmats.2020.578791/pdf](https://www.frontiersin.org/journals/materials/articles/10.3389/fmats.2020.578791/pdf)

\[203] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[204] Thermoelectric transport in graphene and 2D layered Materials[ https://par.nsf.gov/servlets/purl/10084715](https://par.nsf.gov/servlets/purl/10084715)

\[205] Recent Progress of Two-Dimensional Transition Metal Dichalcogenides for Thermoelectric Applications[ https://www.researchgate.net/publication/359163805\_Recent\_Progress\_of\_Two-Dimensional\_Transition\_Metal\_Dichalcogenides\_for\_Thermoelectric\_Applications](https://www.researchgate.net/publication/359163805_Recent_Progress_of_Two-Dimensional_Transition_Metal_Dichalcogenides_for_Thermoelectric_Applications)

\[206] 南科大何佳清团队在热电材料GeTe内部二维量子缺陷的研究中取得一系列进展[ https://science.sustech.edu.cn/portal/Article/index?id=1033\&cid=10\&year=2023\&nav\_id=95](https://science.sustech.edu.cn/portal/Article/index?id=1033\&cid=10\&year=2023\&nav_id=95)

\[207] Coupled Vacancy and Phonon‐Scattering Engineering Drive Defect Evolution Toward Multifunctional High‐Performance Bi2Te3 Thermoelectrics[ https://www.researchgate.net/publication/404399590\_Coupled\_Vacancy\_and\_Phonon-Scattering\_Engineering\_Drive\_Defect\_Evolution\_Toward\_Multifunctional\_High-Performance\_Bi2Te3\_Thermoelectrics](https://www.researchgate.net/publication/404399590_Coupled_Vacancy_and_Phonon-Scattering_Engineering_Drive_Defect_Evolution_Toward_Multifunctional_High-Performance_Bi2Te3_Thermoelectrics)

\[208] Multiscale Defect-Assisted Enhancement of Thermoelectric Transport in Sn-Doped Black Phosphorus Polycrystals[ https://pubs.acs.org/doi/10.1021/acsomega.5c00918](https://pubs.acs.org/doi/10.1021/acsomega.5c00918)

\[209] Defect Engineering Boosted Ultrahigh Thermoelectric Power Conversion Efficiency in Polycrystalline SnSe[ https://scholars.cityu.edu.hk/en/publications/defect-engineering-boosted-ultrahigh-thermoelectric-power-conversion-efficiency-in-polycrystalline-snse(101f9eb4-24be-4fb8-b38f-c87ef1bdaa40).html](https://scholars.cityu.edu.hk/en/publications/defect-engineering-boosted-ultrahigh-thermoelectric-power-conversion-efficiency-in-polycrystalline-snse\(101f9eb4-24be-4fb8-b38f-c87ef1bdaa40\).html)

\[210] Defects Engineering with Multiple Dimensions in Thermoelectric Materials[ https://pmc.ncbi.nlm.nih.gov/articles/PMC7261317/](https://pmc.ncbi.nlm.nih.gov/articles/PMC7261317/)

\[211] Defect-Energy-Targeted Lattice Repair Delivers High Thermoelectric Performance in Magnesium Antimonide[ https://pubs.acs.org/doi/10.1021/jacs.6c02279](https://pubs.acs.org/doi/10.1021/jacs.6c02279)

\[212] Van der Waals interlayer coupling effect on the transport and thermoelectric properties of SnX (X=S or Se) bilayers and heterostructure[ https://pubs.acs.org/doi/suppl/10.1021/acsaem.0c01020/suppl\_file/ae0c01020\_si\_001.pdf](https://pubs.acs.org/doi/suppl/10.1021/acsaem.0c01020/suppl_file/ae0c01020_si_001.pdf)

\[213] Enhanced thermoelectric performance, inter-layer coupling effects and reduced lattice thermal conductivity in two-dimensional transition metal oxides[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12451456/pdf/NA-007-D5NA00303B.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12451456/pdf/NA-007-D5NA00303B.pdf)

\[214] Ultrahigh thermal isolation across heterogeneously layered two-dimensional materials[ https://www.science.org/doi/pdf/10.1126/sciadv.aax1325?download=true](https://www.science.org/doi/pdf/10.1126/sciadv.aax1325?download=true)

\[215] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[216] First-Principles Study of the Heterostructure, ZnSb Bilayer/h-BN Monolayer for Thermoelectric Applications[ https://pdfs.semanticscholar.org/4e58/ec26da822258ef376a08925e8471f6d75ef8.pdf](https://pdfs.semanticscholar.org/4e58/ec26da822258ef376a08925e8471f6d75ef8.pdf)

\[217] Band Alignment of 2D Semiconductors for Designing Heterostructures with Momentum Space Matching[ https://www.researchgate.net/publication/297522692\_Band\_Alignment\_of\_2D\_Semiconductors\_for\_Designing\_Heterostructures\_with\_Momentum\_Space\_Matching](https://www.researchgate.net/publication/297522692_Band_Alignment_of_2D_Semiconductors_for_Designing_Heterostructures_with_Momentum_Space_Matching)

\[218] 理学院物理系何佳清团队在Science发表SnSe热电材料和器件重要成果[ https://science.sustech.edu.cn/portal/article/index/id/860](https://science.sustech.edu.cn/portal/article/index/id/860)

\[219] Interfacial State Modulation toward High-Performance n-Type Bi 2 Te 2.7 Se 0.3 Thermoelectric Material[ https://pubs.acs.org/doi/pdf/10.1021/acsami.5c12988](https://pubs.acs.org/doi/pdf/10.1021/acsami.5c12988)

\[220] Determining the Electronic Structure and Thermoelectric Properties of MoS 2/MoSe 2 Type-I Heterojunction by DFT and the Landauer Approach[ https://advanced.onlinelibrary.wiley.com/doi/full/10.1002/admi.202202339](https://advanced.onlinelibrary.wiley.com/doi/full/10.1002/admi.202202339)

\[221] Te/Si Mixed-Dimensional van der Waals Heterojunction for Artificial Bionic Visual Devices[ https://pubs.acs.org/doi/full/10.1021/acsomega.5c06948](https://pubs.acs.org/doi/full/10.1021/acsomega.5c06948)

\[222] 六方氮化硼的晶体结构、热导特性及在电子封装与二维材料中的应用 - CSDN文库[ https://wenku.csdn.net/doc/7taoeb8xyu](https://wenku.csdn.net/doc/7taoeb8xyu)

\[223] Thickness-Dependent Cross-Plane Thermal Conductivity Measurements of Exfoliated Hexagonal Boron Nitride[ https://pubmed.ncbi.nlm.nih.gov/36848224/](https://pubmed.ncbi.nlm.nih.gov/36848224/)

\[224] Thermal Transport in 2D Materials[ https://pmc.ncbi.nlm.nih.gov/articles/PMC9824888/](https://pmc.ncbi.nlm.nih.gov/articles/PMC9824888/)

\[225] Thermally Conductive Hexagonal Boron Nitride/Polymer Composites for Efficient Heat Transport[ https://www.researchgate.net/publication/381994337\_Thermally\_Conductive\_Hexagonal\_Boron\_NitridePolymer\_Composites\_for\_Efficient\_Heat\_Transport](https://www.researchgate.net/publication/381994337_Thermally_Conductive_Hexagonal_Boron_NitridePolymer_Composites_for_Efficient_Heat_Transport)

\[226] Title:Hexagonal Boron Nitride-Graphene Heterostructures with Enhanced Interfacial Thermal Conductance for Thermal Management Applications[ https://arxiv.org/abs/2104.04693](https://arxiv.org/abs/2104.04693)

\[227] Phonon thermal conductivity of the stanene/hBN van der Waals heterostructure[ https://www.researchgate.net/publication/351335018\_Phonon\_thermal\_conductivity\_of\_the\_stanenehBN\_van\_der\_Waals\_heterostructure](https://www.researchgate.net/publication/351335018_Phonon_thermal_conductivity_of_the_stanenehBN_van_der_Waals_heterostructure)

\[228] Temperature ZT Research Articles[ https://discovery.researcher.life/topic/temperature-zt/2382436?topic\_name=Temperature%20ZT](https://discovery.researcher.life/topic/temperature-zt/2382436?topic_name=Temperature%20ZT)

\[229] Recent Progress of Two-Dimensional Transition Metal Dichalcogenides for Thermoelectric Applications[ https://www.researchgate.net/publication/359163805\_Recent\_Progress\_of\_Two-Dimensional\_Transition\_Metal\_Dichalcogenides\_for\_Thermoelectric\_Applications](https://www.researchgate.net/publication/359163805_Recent_Progress_of_Two-Dimensional_Transition_Metal_Dichalcogenides_for_Thermoelectric_Applications)

\[230] 南科大何佳清团队在热电材料GeTe内部二维量子缺陷的研究中取得一系列进展[ https://science.sustech.edu.cn/portal/Article/index?id=1033\&cid=10\&year=2023\&nav\_id=95](https://science.sustech.edu.cn/portal/Article/index?id=1033\&cid=10\&year=2023\&nav_id=95)

\[231] Coupled Vacancy and Phonon‐Scattering Engineering Drive Defect Evolution Toward Multifunctional High‐Performance Bi2Te3 Thermoelectrics[ https://www.researchgate.net/publication/404399590\_Coupled\_Vacancy\_and\_Phonon-Scattering\_Engineering\_Drive\_Defect\_Evolution\_Toward\_Multifunctional\_High-Performance\_Bi2Te3\_Thermoelectrics](https://www.researchgate.net/publication/404399590_Coupled_Vacancy_and_Phonon-Scattering_Engineering_Drive_Defect_Evolution_Toward_Multifunctional_High-Performance_Bi2Te3_Thermoelectrics)

\[232] Defect-Energy-Targeted Lattice Repair Delivers High Thermoelectric Performance in Magnesium Antimonide[ https://pubs.acs.org/doi/10.1021/jacs.6c02279](https://pubs.acs.org/doi/10.1021/jacs.6c02279)

\[233] Defect Engineering Boosted Ultrahigh Thermoelectric Power Conversion Efficiency in Polycrystalline SnSe[ https://scholars.cityu.edu.hk/en/publications/defect-engineering-boosted-ultrahigh-thermoelectric-power-conversion-efficiency-in-polycrystalline-snse(101f9eb4-24be-4fb8-b38f-c87ef1bdaa40).html](https://scholars.cityu.edu.hk/en/publications/defect-engineering-boosted-ultrahigh-thermoelectric-power-conversion-efficiency-in-polycrystalline-snse\(101f9eb4-24be-4fb8-b38f-c87ef1bdaa40\).html)

\[234] Multiscale Defect-Assisted Enhancement of Thermoelectric Transport in Sn-Doped Black Phosphorus Polycrystals[ https://pubs.acs.org/doi/10.1021/acsomega.5c00918](https://pubs.acs.org/doi/10.1021/acsomega.5c00918)

\[235] Engineering heat transport across epitaxial lattice-mismatched van der Waals heterointerfaces[ https://arxiv.org/pdf/2303.05808v1](https://arxiv.org/pdf/2303.05808v1)

\[236] Enhanced thermoelectric performance, inter-layer coupling effects and reduced lattice thermal conductivity in two-dimensional transition metal oxides[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12451456/pdf/NA-007-D5NA00303B.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12451456/pdf/NA-007-D5NA00303B.pdf)

\[237] TMD Cs and related vdW-heterostructures: a gap analysis of hybrid synthesis and the realization of optimal properties for practical applications, current challenges, and future prospects[ https://www.tandfonline.com/doi/pdf/10.1080/23746149.2025.2580625](https://www.tandfonline.com/doi/pdf/10.1080/23746149.2025.2580625)

\[238] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[239] Substrate-dependence of monolayer MoS₂ thermal conductivity and thermal boundary conductance[ https://poplab.stanford.edu/pdfs/Gabourie-SubstrateDepMoS2thermalK-jap22.pdf](https://poplab.stanford.edu/pdfs/Gabourie-SubstrateDepMoS2thermalK-jap22.pdf)

\[240] Measuring the thermal conductivity of a Si substrate and SiO2 film by the 3ω method. (a) Resistance of a Cr/Au electrode versus temperature. (b) Temperature changes versus the frequency of AC-current [ https://www.researchgate.net/figure/Measuring-the-thermal-conductivity-of-a-Si-substrate-and-SiO2-film-by-the-3o-method-a\_fig1\_313535746](https://www.researchgate.net/figure/Measuring-the-thermal-conductivity-of-a-Si-substrate-and-SiO2-film-by-the-3o-method-a_fig1_313535746)

\[241] Phonon thermal conductivity of monolayer MoS2 sheet and nanoribbons[ https://www.researchgate.net/publication/260705377\_Phonon\_thermal\_conductivity\_of\_monolayer\_MoS2\_sheet\_and\_nanoribbons](https://www.researchgate.net/publication/260705377_Phonon_thermal_conductivity_of_monolayer_MoS2_sheet_and_nanoribbons)

\[242] Large enhancement of thermoelectric performance in MoS/-BN heterostructure due to vacancy-induced band hybridization[ https://pubmed.ncbi.nlm.nih.gov/32522877/](https://pubmed.ncbi.nlm.nih.gov/32522877/)

\[243] Quantitative Predictions of the Thermal Conductivity in Transition Metal Dichalcogenides: Impact of Point Defects in MoS 2 and WS 2 Monolayers[ https://pubs.acs.org/doi/10.1021/acs.jpcc.3c06820](https://pubs.acs.org/doi/10.1021/acs.jpcc.3c06820)

\[244] Homogeneity and tolerance to heat of monolayer MoS2 on SiO2 and h-BN - PubMed[ https://pubmed.ncbi.nlm.nih.gov/35541259/](https://pubmed.ncbi.nlm.nih.gov/35541259/)

\[245] 南科大何佳清团队在热电材料GeTe内部二维量子缺陷的研究中取得一系列进展[ https://science.sustech.edu.cn/portal/Article/index?id=1033\&cid=10\&year=2023\&nav\_id=95](https://science.sustech.edu.cn/portal/Article/index?id=1033\&cid=10\&year=2023\&nav_id=95)

\[246] Multiscale Defect-Assisted Enhancement of Thermoelectric Transport in Sn-Doped Black Phosphorus Polycrystals[ https://pubs.acs.org/doi/10.1021/acsomega.5c00918](https://pubs.acs.org/doi/10.1021/acsomega.5c00918)

\[247] Strong reduction of thermal conductivity of WSe2with introduction of atomic defects - PubMed[ https://pubmed.ncbi.nlm.nih.gov/35349994/](https://pubmed.ncbi.nlm.nih.gov/35349994/)

\[248] Recent Progress of Two-Dimensional Transition Metal Dichalcogenides for Thermoelectric Applications[ https://www.researchgate.net/publication/359163805\_Recent\_Progress\_of\_Two-Dimensional\_Transition\_Metal\_Dichalcogenides\_for\_Thermoelectric\_Applications](https://www.researchgate.net/publication/359163805_Recent_Progress_of_Two-Dimensional_Transition_Metal_Dichalcogenides_for_Thermoelectric_Applications)

\[249] Coupled Vacancy and Phonon‐Scattering Engineering Drive Defect Evolution Toward Multifunctional High‐Performance Bi2Te3 Thermoelectrics[ https://www.researchgate.net/publication/404399590\_Coupled\_Vacancy\_and\_Phonon-Scattering\_Engineering\_Drive\_Defect\_Evolution\_Toward\_Multifunctional\_High-Performance\_Bi2Te3\_Thermoelectrics](https://www.researchgate.net/publication/404399590_Coupled_Vacancy_and_Phonon-Scattering_Engineering_Drive_Defect_Evolution_Toward_Multifunctional_High-Performance_Bi2Te3_Thermoelectrics)

\[250] Phonon Engineering in Two-Dimensional Materials for Thermal Devices[ https://media.sciltp.com/articles/2603003373/2603003373.pdf](https://media.sciltp.com/articles/2603003373/2603003373.pdf)

\[251] Defects Engineering with Multiple Dimensions in Thermoelectric Materials[ https://pmc.ncbi.nlm.nih.gov/articles/PMC7261317/](https://pmc.ncbi.nlm.nih.gov/articles/PMC7261317/)

\[252] Interlayer Exciton–Phonon Coupling in MoSe₂/WSe₂ Heterostructures[ https://refubium.fu-berlin.de/bitstream/handle/fub188/44942/nl4c02757.pdf;jsessionid=6CA45AA9B75CA3AE7DE184AFD7D5BA1F?sequence=2](https://refubium.fu-berlin.de/bitstream/handle/fub188/44942/nl4c02757.pdf;jsessionid=6CA45AA9B75CA3AE7DE184AFD7D5BA1F?sequence=2)

\[253] Interlayer Exciton-Phonon Coupling in MoSe2/WSe2 Heterostructures - PubMed[ https://pubmed.ncbi.nlm.nih.gov/39265089/](https://pubmed.ncbi.nlm.nih.gov/39265089/)

\[254] Interlayer Exciton-Phonon Coupling in \\(MoSe\_{2} / WSe\_{2}\\)[ https://pubs.acs.org/doi/suppl/10.1021/acs.nanolett.4c05914/suppl\_file/nl4c05914\_si\_001.pdf](https://pubs.acs.org/doi/suppl/10.1021/acs.nanolett.4c05914/suppl_file/nl4c05914_si_001.pdf)

\[255] Spectroscopic signatures for interlayer coupling in MoS2-WSe2 van der Waals stacking[ https://pubmed.ncbi.nlm.nih.gov/25196077/](https://pubmed.ncbi.nlm.nih.gov/25196077/)

\[256] Tuning of Interlayer Interaction in MoS 2 –WS 2 van der Waals Heterostructures Using Hydrostatic Pressure[ https://www.researchgate.net/publication/370109895\_Tuning\_of\_Interlayer\_Interaction\_in\_MoS\_2\_-WS\_2\_van\_der\_Waals\_Heterostructures\_Using\_Hydrostatic\_Pressure](https://www.researchgate.net/publication/370109895_Tuning_of_Interlayer_Interaction_in_MoS_2_-WS_2_van_der_Waals_Heterostructures_Using_Hydrostatic_Pressure)

\[257] Enhanced interlayer coupling and efficient photodetection response of in-situ grown MoS> 2> -WS> 2> van der Waals heterostructures - Beijing Institute of Technology[ https://pure.bit.edu.cn/en/publications/enhanced-interlayer-coupling-and-efficient-photodetection-respons/](https://pure.bit.edu.cn/en/publications/enhanced-interlayer-coupling-and-efficient-photodetection-respons/)

\[258] Near-Infrared Photoresponse Driven by Strong Interlayer Transition in 2D MoSe 2/WSe 2 van der Waals Heterostructures: Implications for Broadband Photodetectors[ https://pubs.acs.org/doi/pdf/10.1021/acsanm.4c06290](https://pubs.acs.org/doi/pdf/10.1021/acsanm.4c06290)

\[259] Engineering of MoSe 2 and WSe 2 Monolayers and Heterostructures by DFT-Molecular Dynamics Simulations[ https://pubs.acs.org/doi/10.1021/acsami.5c07971](https://pubs.acs.org/doi/10.1021/acsami.5c07971)

\[260] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[261] 二维共价键子结构 Zintl 相热电材料研究及进展[ https://wulixb.iphy.ac.cn/fileWLXB/journal/article/wlxb/newcreate/20211010.pdf;](https://wulixb.iphy.ac.cn/fileWLXB/journal/article/wlxb/newcreate/20211010.pdf;)

\[262] Enhanced Thermoelectric Performance in 2D ZrX2N4 (X = Si, Ge) Monolayers: A First-Principles Study[ https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159](https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159)

\[263] Enhanced Thermoelectric Properties of Phosphorene via Quantum Size Effects and Relaxation Time Tuning[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12156281/pdf/materials-18-02506.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12156281/pdf/materials-18-02506.pdf)

\[264] 废热变电能 “中国薄膜”创柔性热电材料世界纪录--经济·科技--人民网[ http://finance.people.com.cn/BIG5/n1/2026/0306/c1004-40676229.html](http://finance.people.com.cn/BIG5/n1/2026/0306/c1004-40676229.html)

\[265] ウェアラブル発電用の高性能フレキシブル材料を開発 (Chinese Researchers Develop Advanced Flexible Material for Wearable Power Generation)[ https://tiisys.com/blog/2026/03/10/post-187516/](https://tiisys.com/blog/2026/03/10/post-187516/)

\[266] Thermoelectric properties of M 2 BS 2 (M = Ti, Zr, Hf) monolayers: An Ab initio study[ https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290)

\[267] Progress, Challenges, and Opportunities in the Synthesis, Characterization, and Application of Metal-Boride-Derived Two-Dimensional Nanostructures[ https://www.researchgate.net/publication/350901381\_Progress\_Challenges\_and\_Opportunities\_in\_the\_Synthesis\_Characterization\_and\_Application\_of\_Metal-Boride-Derived\_Two-Dimensional\_Nanostructures](https://www.researchgate.net/publication/350901381_Progress_Challenges_and_Opportunities_in_the_Synthesis_Characterization_and_Application_of_Metal-Boride-Derived_Two-Dimensional_Nanostructures)

\[268] Two-Dimensional Black Phosphorus Nanomaterials: Emerging Advances in Electrochemical Energy Storage Science[ https://pmc.ncbi.nlm.nih.gov/articles/PMC7770910/](https://pmc.ncbi.nlm.nih.gov/articles/PMC7770910/)

\[269] Exploring the advances in 2D materials as a quest for energy storage electrode materials[ https://pubs.rsc.org/en/content/articlepdf/2026/ra/d5ra07292a?page=search](https://pubs.rsc.org/en/content/articlepdf/2026/ra/d5ra07292a?page=search)

\[270] Enhanced Thermoelectric Performance in Black Phosphorene via Tunable Interlayer Twist[ https://www.researchgate.net/publication/364760123\_Enhanced\_Thermoelectric\_Performance\_in\_Black\_Phosphorene\_via\_Tunable\_Interlayer\_Twist](https://www.researchgate.net/publication/364760123_Enhanced_Thermoelectric_Performance_in_Black_Phosphorene_via_Tunable_Interlayer_Twist)

\[271] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[272] Incorporation of MXene into Bi 2 S 3 Matrix Promotes Better Electron Transport and Enhanced Thermoelectric Figure of Merit[ https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651](https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651)

\[273] Enhanced Thermoelectric Performance in 2D ZrX2N4 (X = Si, Ge) Monolayers: A First-Principles Study[ https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159](https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159)

\[274] From Chaos to Order: Designing MXenes Surface with Record-high Conductivity[ https://www.mpi-halle.mpg.de/857946/2026-01-27-rn-smfd?print=yes](https://www.mpi-halle.mpg.de/857946/2026-01-27-rn-smfd?print=yes)

\[275] MXene breakthrough boosts conductivity 160x with perfect atomic order[ https://www.sciencedaily.com/releases/2026/04/260403224457.htm](https://www.sciencedaily.com/releases/2026/04/260403224457.htm)

\[276] A New Way to Build 2D Materials Without Harsh Chemicals Pays Off Big[ https://advancedcarbonscouncil.org/blogpost/2151389/517369/A-New-Way-to-Build-2D-Materials-Without-Harsh-Chemicals-Pays-Off-Big?tag=Advanced+Carbons+Council](https://advancedcarbonscouncil.org/blogpost/2151389/517369/A-New-Way-to-Build-2D-Materials-Without-Harsh-Chemicals-Pays-Off-Big?tag=Advanced+Carbons+Council)

\[277] 二维共价键子结构Zintl相热电材料研究及进展[ https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.70.20211010?viewType=References](https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.70.20211010?viewType=References)

\[278] Thermoelectric Properties of Two-Dimensional Selenene and Tellurene from Group-VI Elements[ https://www.researchgate.net/publication/327214515\_Thermoelectric\_Properties\_of\_Two-Dimensional\_Selenene\_and\_Tellurene\_from\_Group-VI\_Elements](https://www.researchgate.net/publication/327214515_Thermoelectric_Properties_of_Two-Dimensional_Selenene_and_Tellurene_from_Group-VI_Elements)

\[279] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[280] Thermoelectric properties of M 2 BS 2 (M = Ti, Zr, Hf) monolayers: An Ab initio study[ https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290)

\[281] Enhanced Thermoelectric Performance in 2D ZrX2N4 (X = Si, Ge) Monolayers: A First-Principles Study[ https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159](https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159)

\[282] High Power Factor vs. High zT—A Review of Thermoelectric Materials for High-Temperature Application[ https://pmc.ncbi.nlm.nih.gov/articles/PMC7514362/](https://pmc.ncbi.nlm.nih.gov/articles/PMC7514362/)

\[283] 双轴应变对单层Janus过渡金属硫族化合物热输运和热电性能的影响[ https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295](https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295)

\[284] First-Principles Investigation of Simultaneous Thermoelectric Power Generation and Active Cooling in a Bifunctional Semimetal ZrSeTe Janus Structure[ https://pmc.ncbi.nlm.nih.gov/articles/PMC10818368/pdf/nanomaterials-14-00234.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC10818368/pdf/nanomaterials-14-00234.pdf)

\[285] Decoding unique electronic and phononic features in Janus systems beneficial for thermoelectricity[ https://pubs.aip.org/aip/jap/article-pdf/doi/10.1063/5.0277369/20560911/235103\_1\_5.0277369.pdf](https://pubs.aip.org/aip/jap/article-pdf/doi/10.1063/5.0277369/20560911/235103_1_5.0277369.pdf)

\[286] Citation Report[ https://exaly.com/article-pdf/134828935/citation-report.pdf](https://exaly.com/article-pdf/134828935/citation-report.pdf)

\[287] Deciphering Cationic/Anionic Substitutions Decouple Phononic and Electronic Transport, Enabling High Thermoelectricity in Heterostructures[ https://pubs.acs.org/doi/abs/10.1021/acsaem.5c02543](https://pubs.acs.org/doi/abs/10.1021/acsaem.5c02543)

\[288] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[289] Origins of Minimized Lattice Thermal Conductivity and Enhanced Thermoelectric Performance in WS 2/WSe 2 Lateral Superlattice[ https://pubs.acs.org/doi/full/10.1021/acsomega.1c00457](https://pubs.acs.org/doi/full/10.1021/acsomega.1c00457)

\[290] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[291] n型Ti3C2Tx MXene及其复合薄膜的制备与热电性能调控.pdf-原创力文档[ https://m.book118.com/html/2026/0308/8132113120010051.shtm](https://m.book118.com/html/2026/0308/8132113120010051.shtm)

\[292] Thirty Years of Borophene: Origins, Scientific Progress, and Future Directions[ https://pubs.acs.org/doi/10.1021/acsami.5c19994](https://pubs.acs.org/doi/10.1021/acsami.5c19994)

\[293] Vol. 70, No. 20 (2021)[ https://wulixb.iphy.ac.cn/en/custom/2021/20](https://wulixb.iphy.ac.cn/en/custom/2021/20)

\[294] Incorporation of MXene into Bi 2 S 3 Matrix Promotes Better Electron Transport and Enhanced Thermoelectric Figure of Merit[ https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651](https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651)

\[295] Advanced perspectives on MXene composite nanomaterials: Types synthetic methods, thermal energy utilization and 3D-printed techniques[ https://pmc.ncbi.nlm.nih.gov/articles/PMC9826899/](https://pmc.ncbi.nlm.nih.gov/articles/PMC9826899/)

\[296] Themed collection Journal of Materials Chemistry A HOT Papers[ https://pubs.rsc.org/en/journals/articlecollectionlanding?sercode=ta\&themeid=a863a603-b629-4bb0-b1ce-5a5f15f2ba8c](https://pubs.rsc.org/en/journals/articlecollectionlanding?sercode=ta\&themeid=a863a603-b629-4bb0-b1ce-5a5f15f2ba8c)

\[297] Incorporation of MXene into Bi2S3 Matrix Promotes Better Electron Transport and Enhanced Thermoelectric Figure of Merit - PubMed[ https://ncbi.nlm.nih.gov/pubmed/40910179](https://ncbi.nlm.nih.gov/pubmed/40910179)

\[298] Thermoelectric transport properties of borophane[ https://arxiv.org/pdf/1811.09915v1](https://arxiv.org/pdf/1811.09915v1)

\[299] Superior Thermoelectric Properties of Twist-Angle Superlattice Borophene Induced by Interlayer Electrons Transport - PubMed[ https://pubmed.ncbi.nlm.nih.gov/36919623/](https://pubmed.ncbi.nlm.nih.gov/36919623/)

\[300] Promising Thermoelectric Performance in Two-Dimensional Semiconducting Boron Monolayer[ https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.739984/full](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.739984/full)

\[301] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[302] Enhanced Thermoelectric Performance of Nanostructured 2D Tin Telluride[ https://pubmed.ncbi.nlm.nih.gov/38873904/](https://pubmed.ncbi.nlm.nih.gov/38873904/)

\[303] 二维共价键子结构 Zintl 相热电材料研究及进展[ https://wulixb.iphy.ac.cn/fileWLXB/journal/article/wlxb/newcreate/20211010.pdf;](https://wulixb.iphy.ac.cn/fileWLXB/journal/article/wlxb/newcreate/20211010.pdf;)

\[304] Recent Progress of Two-Dimensional Transition Metal Dichalcogenides for Thermoelectric Applications[ https://www.researchgate.net/publication/359163805\_Recent\_Progress\_of\_Two-Dimensional\_Transition\_Metal\_Dichalcogenides\_for\_Thermoelectric\_Applications](https://www.researchgate.net/publication/359163805_Recent_Progress_of_Two-Dimensional_Transition_Metal_Dichalcogenides_for_Thermoelectric_Applications)

\[305] High Power Factor vs. High zT—A Review of Thermoelectric Materials for High-Temperature Application[ https://pmc.ncbi.nlm.nih.gov/articles/PMC7514362/](https://pmc.ncbi.nlm.nih.gov/articles/PMC7514362/)

\[306] 双轴应变对单层Janus过渡金属硫族化合物热输运和热电性能的影响[ https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295](https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295)

\[307] Reaching Excitonic Limit in 2D Janus Monolayers by In‐situ Deterministic Growth[ https://www.researchgate.net/publication/356494570\_Reaching\_Excitonic\_Limit\_in\_2D\_Janus\_Monolayers\_by\_In-situ\_Deterministic\_Growth](https://www.researchgate.net/publication/356494570_Reaching_Excitonic_Limit_in_2D_Janus_Monolayers_by_In-situ_Deterministic_Growth)

\[308] Excellent thermoelectric performance and impressive optoelectronic properties of Janus monolayer of ZrXY(X=O, S) (Y=S, Se)[ https://arxiv.org/pdf/2206.08997](https://arxiv.org/pdf/2206.08997)

\[309] Anomalous Dependence of Seebeck Coefficient and ZT  Value on Van Hove Singularity: A Case Study of Janus 2H-WSH Monolayer[ https://pubs.acs.org/doi/abs/10.1021/acsaem.4c03051](https://pubs.acs.org/doi/abs/10.1021/acsaem.4c03051)

\[310] High Thermoelectric Performance in Two-Dimensional Janus Monolayer Material WS-X (X = Se and Te)[ https://pubs.acs.org/doi/pdf/10.1021/acsami.0c13960](https://pubs.acs.org/doi/pdf/10.1021/acsami.0c13960)

\[311] First-Principles Investigation of Simultaneous Thermoelectric Power Generation and Active Cooling in a Bifunctional Semimetal ZrSeTe Janus Structure[ https://pmc.ncbi.nlm.nih.gov/articles/PMC10818368/pdf/nanomaterials-14-00234.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC10818368/pdf/nanomaterials-14-00234.pdf)

\[312] Investigation of thermoelectric properties of flexible Ti₃C₂Tₓ MXene membranes[ https://pubs.rsc.org/en/content/articlepdf/2026/ra/d5ra07980b?page=search](https://pubs.rsc.org/en/content/articlepdf/2026/ra/d5ra07980b?page=search)

\[313] Three dimensional architected thermoelectric devices with high toughness and power conversion efficiency[ https://pmc.ncbi.nlm.nih.gov/articles/PMC10097747/pdf/41467\_2023\_Article\_37707.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC10097747/pdf/41467_2023_Article_37707.pdf)

\[314] Incorporation of MXene into Bi 2 S 3 Matrix Promotes Better Electron Transport and Enhanced Thermoelectric Figure of Merit[ https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651](https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651)

\[315] Unlocking the thermoelectric potential of the Ca 14 AlSb 11  structure type[ https://www.ovid.com/journals/sciad/fulltext/10.1126/sciadv.abq3780\~unlocking-the-thermoelectric-potential-of-the-ca14alsb11](https://www.ovid.com/journals/sciad/fulltext/10.1126/sciadv.abq3780~unlocking-the-thermoelectric-potential-of-the-ca14alsb11)

\[316] Enhanced Thermoelectric Performance of Rare-Earth-Free n-Type Oxide Perovskite Composite with Graphene Analogous 2D MXene[ https://pubmed.ncbi.nlm.nih.gov/36852637/](https://pubmed.ncbi.nlm.nih.gov/36852637/)

\[317] Simultaneously Enhanced Thermoelectric and Mechanical Properties in Mg 3 (Sb,Bi) 2 by MXene Compositing for Automotive Waste Heat Recovery[ https://pubs.acs.org/doi/pdf/10.1021/acs.chemmater.5c01463](https://pubs.acs.org/doi/pdf/10.1021/acs.chemmater.5c01463)

\[318] 二维共价键子结构Zintl相热电材料研究及进展[ https://wulixb.iphy.ac.cn/article/doi/10.7498/aps.70.20211010?viewType=References](https://wulixb.iphy.ac.cn/article/doi/10.7498/aps.70.20211010?viewType=References)

\[319] Enhanced Thermoelectric Performance of Nanostructured 2D Tin Telluride[ https://pubmed.ncbi.nlm.nih.gov/38873904/](https://pubmed.ncbi.nlm.nih.gov/38873904/)

\[320] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[321] Thermoelectric properties of M 2 BS 2 (M = Ti, Zr, Hf) monolayers: An Ab initio study[ https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290)

\[322] Thermoelectric properties of monolayer Cu2X[ https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.72.20222015?viewType=References](https://wulixb.iphy.ac.cn/en/article/doi/10.7498/aps.72.20222015?viewType=References)

\[323] Enhanced Thermoelectric Performance in 2D ZrX2N4 (X = Si, Ge) Monolayers: A First-Principles Study[ https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159](https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159)

\[324] Incorporation of MXene into Bi2S3 Matrix Promotes Better Electron Transport and Enhanced Thermoelectric Figure of Merit - PubMed[ https://ncbi.nlm.nih.gov/pubmed/40910179](https://ncbi.nlm.nih.gov/pubmed/40910179)

\[325] Highly Thermoelectric ZnO@MXene (TiCT) Composite Films Grown by Atomic Layer Deposition[ https://pubmed.ncbi.nlm.nih.gov/35876013/](https://pubmed.ncbi.nlm.nih.gov/35876013/)

\[326] Enhanced Thermoelectric Performance of Rare-Earth-Free n-Type Oxide Perovskite Composite with Graphene Analogous 2D MXene[ https://pubmed.ncbi.nlm.nih.gov/36852637/](https://pubmed.ncbi.nlm.nih.gov/36852637/)

\[327] Simultaneously Enhanced Thermoelectric and Mechanical Properties in Mg 3 (Sb,Bi) 2 by MXene Compositing for Automotive Waste Heat Recovery[ https://pubs.acs.org/doi/pdf/10.1021/acs.chemmater.5c01463](https://pubs.acs.org/doi/pdf/10.1021/acs.chemmater.5c01463)

\[328] Incorporation of MXene into Bi 2 S 3 Matrix Promotes Better Electron Transport and Enhanced Thermoelectric Figure of Merit[ https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651](https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651)

\[329] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/fr/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[330] Biomedical potentials of MXene-based self-powered wearable devices: the future of next-generation wearables[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12439251/pdf/RA-015-D5RA04611D.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12439251/pdf/RA-015-D5RA04611D.pdf)

\[331] 双轴应变对单层Janus过渡金属硫族化合物热输运和热电性能的影响[ https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295](https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295)

\[332] High Thermoelectric Performance in Two-Dimensional Janus Monolayer Material WS-X (X = Se and Te)[ https://pubs.acs.org/doi/pdf/10.1021/acsami.0c13960](https://pubs.acs.org/doi/pdf/10.1021/acsami.0c13960)

\[333] Excellent thermoelectric performance and impressive optoelectronic properties of Janus monolayer of ZrXY(X=O, S) (Y=S, Se)[ https://arxiv.org/pdf/2206.08997](https://arxiv.org/pdf/2206.08997)

\[334] Novel Janus 2H-Tl 2 SSe Monolayer with Ultralow Lattice Thermal Conductivity and Outstanding Thermoelectric Performance[ https://pubs.acs.org/doi/10.1021/acs.jpcc.4c05100](https://pubs.acs.org/doi/10.1021/acs.jpcc.4c05100)

\[335] Influence of Janus structure on the thermoelectric performance of the α-Se monolayer - Beijing Institute of Technology[ http://pure.bit.edu.cn/en/publications/influence-of-janus-structure-on-the-thermoelectric-performance-of](http://pure.bit.edu.cn/en/publications/influence-of-janus-structure-on-the-thermoelectric-performance-of)

\[336] The coexistence of superior intrinsic piezoelectricity and thermoelectricity in two-dimensional Janus α-TeSSe - PubMed[ https://pubmed.ncbi.nlm.nih.gov/34842246/](https://pubmed.ncbi.nlm.nih.gov/34842246/)

\[337] 双轴应变对单层Janus过渡金属硫族化合物热输运和热电性能的影响 \[Influence of biaxial strain effects on thermal transport and thermoelectric performance of Janus transition metal dichalcogenide monolayers] - CORE[ https://core.ac.uk/outputs/666792042/](https://core.ac.uk/outputs/666792042/)

\[338] Promising Thermoelectric Performance of Janus Monolayer ZrBrI[ https://www.mdpi.com/1996-1944/19/9/1716](https://www.mdpi.com/1996-1944/19/9/1716)

\[339] Promising Thermoelectric Performance in Two-Dimensional Semiconducting Boron Monolayer[ https://public-pages-files-2025.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.739984/pdf](https://public-pages-files-2025.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.739984/pdf)

\[340] A review of thermal transport and electronic properties of borophene[ https://arxiv.org/pdf/1801.02291v1](https://arxiv.org/pdf/1801.02291v1)

\[341] Promising Thermoelectric Performance in Two-Dimensional Semiconducting Boron Monolayer[ https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.739984/full](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.739984/full)

\[342] Nickel Phthalocyanine: Borophene P-N Junction-Based Thermoelectric Generator[ https://www.mdpi.com/1996-1944/18/12/2850/xml](https://www.mdpi.com/1996-1944/18/12/2850/xml)

\[343] Thermoelectric transport properties of borophane[ https://arxiv.org/pdf/1811.09915v1](https://arxiv.org/pdf/1811.09915v1)

\[344] Cryo‐Exfoliation Synthesis of Borophene and its Application in Wearable Electronics - Li - 2025 - Advanced Science - Wiley Online Library[ https://advanced.onlinelibrary.wiley.com/doi/10.1002/advs.202502257](https://advanced.onlinelibrary.wiley.com/doi/10.1002/advs.202502257)

\[345] Thirty Years of Borophene: Origins, Scientific Progress, and Future Directions[ https://pubs.acs.org/doi/10.1021/acsami.5c19994](https://pubs.acs.org/doi/10.1021/acsami.5c19994)

\[346] 二维共价键子结构Zintl相热电材料研究及进展[ https://wulixb.iphy.ac.cn/article/doi/10.7498/aps.70.20211010?viewType=References](https://wulixb.iphy.ac.cn/article/doi/10.7498/aps.70.20211010?viewType=References)

\[347] 基于二维碲化锗(GeTe)的热电材料综述-CSDN博客[ https://blog.csdn.net/MS\_YangZhanZhang/article/details/136295884](https://blog.csdn.net/MS_YangZhanZhang/article/details/136295884)

\[348] Thermoelectric properties of M 2 BS 2 (M = Ti, Zr, Hf) monolayers: An Ab initio study[ https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0339290)

\[349] Nanostructured Semiconductors for Flexible Thermoelectric Applications[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12735830/pdf/nanomaterials-15-01843.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12735830/pdf/nanomaterials-15-01843.pdf)

\[350] Enhanced Thermoelectric Performance in 2D ZrX2N4 (X = Si, Ge) Monolayers: A First-Principles Study[ https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159](https://onlinelibrary.wiley.com/doi/abs/10.1002/pssb.202500159)

\[351] High Power Factor vs. High zT—A Review of Thermoelectric Materials for High-Temperature Application[ https://pmc.ncbi.nlm.nih.gov/articles/PMC7514362/](https://pmc.ncbi.nlm.nih.gov/articles/PMC7514362/)

\[352] Enhancing Thermoelectric Efficiency in Twisted Bilayer PdSe 2[ https://pubs.acs.org/doi/10.1021/acsaem.4c01336](https://pubs.acs.org/doi/10.1021/acsaem.4c01336)

\[353] Highly Thermoelectric ZnO@MXene (TiCT) Composite Films Grown by Atomic Layer Deposition[ https://pubmed.ncbi.nlm.nih.gov/35876013/](https://pubmed.ncbi.nlm.nih.gov/35876013/)

\[354] Simultaneously Enhanced Thermoelectric and Mechanical Properties in Mg 3 (Sb,Bi) 2 by MXene Compositing for Automotive Waste Heat Recovery[ https://pubs.acs.org/doi/full/10.1021/acs.chemmater.5c01463](https://pubs.acs.org/doi/full/10.1021/acs.chemmater.5c01463)

\[355] Enhanced Thermoelectric Performance of Rare-Earth-Free n-Type Oxide Perovskite Composite with Graphene Analogous 2D MXene[ https://pubmed.ncbi.nlm.nih.gov/36852637/](https://pubmed.ncbi.nlm.nih.gov/36852637/)

\[356] Incorporation of MXene into Bi 2 S 3 Matrix Promotes Better Electron Transport and Enhanced Thermoelectric Figure of Merit[ https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651](https://pubs.acs.org/doi/pdf/10.1021/acsami.4c19651)

\[357] Nanostructured Thermoelectric Materials: The 2026 Innovation Landscape[ https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/](https://www.patsnap.com/resources/blog/rd-blog/nanostructured-thermoelectric-materials-2026-patsnap-eureka/)

\[358] Themed collection Journal of Materials Chemistry C HOT Papers[ https://pubs.rsc.org/ga/journals/articlecollectionlanding?themeid=dbeacc26-6f90-4a7c-851d-c02583f3b81d](https://pubs.rsc.org/ga/journals/articlecollectionlanding?themeid=dbeacc26-6f90-4a7c-851d-c02583f3b81d)

\[359] Phonon Transport in Defect-Laden Bilayer Janus PtSTe Studied Using Neural-Network Force Fields[ https://pubs.acs.org/doi/10.1021/acs.jpcc.4c02454](https://pubs.acs.org/doi/10.1021/acs.jpcc.4c02454)

\[360] 双轴应变对单层Janus过渡金属硫族化合物热输运和热电性能的影响[ https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295](https://wulixb.iphy.ac.cn/cn/article/doi/10.7498/aps.74.20250295)

\[361] Novel Janus 2H-Tl 2 SSe Monolayer with Ultralow Lattice Thermal Conductivity and Outstanding Thermoelectric Performance[ https://pubs.acs.org/doi/pdf/10.1021/acs.jpcc.4c05100](https://pubs.acs.org/doi/pdf/10.1021/acs.jpcc.4c05100)

\[362] Promising Thermoelectric Performance of Janus Monolayer ZrBrI[ https://www.mdpi.com/1996-1944/19/9/1716](https://www.mdpi.com/1996-1944/19/9/1716)

\[363] The coexistence of superior intrinsic piezoelectricity and thermoelectricity in two-dimensional Janus α-TeSSe - PubMed[ https://pubmed.ncbi.nlm.nih.gov/34842246/](https://pubmed.ncbi.nlm.nih.gov/34842246/)

\[364] 双轴应变对单层Janus过渡金属硫族化合物热输运和热电性能的影响 \[Influence of biaxial strain effects on thermal transport and thermoelectric performance of Janus transition metal dichalcogenide monolayers] - CORE[ https://core.ac.uk/outputs/666792042/](https://core.ac.uk/outputs/666792042/)

\[365] 世界初、超高性能熱電半金属に潜む「プラズモニックポーラロン」を直接観測[ https://www.kek.jp/ja/press/202603021400](https://www.kek.jp/ja/press/202603021400)

\[366] 实验成功制备双层硼烯 - 中国科学院物理研究所[ https://www.iop.cas.cn/xwzx/kydt/202111/t20211115\_6255885.html](https://www.iop.cas.cn/xwzx/kydt/202111/t20211115_6255885.html)

\[367] Nickel Phthalocyanine: Borophene P-N Junction-Based Thermoelectric Generator[ https://pdfs.semanticscholar.org/ab45/15aa2c81b51ead4234ee323dc41634bcb92a.pdf](https://pdfs.semanticscholar.org/ab45/15aa2c81b51ead4234ee323dc41634bcb92a.pdf)

\[368] Cryo‐Exfoliation Synthesis of Borophene and its Application in Wearable Electronics - Li - 2025 - Advanced Science - Wiley Online Library[ https://advanced.onlinelibrary.wiley.com/doi/10.1002/advs.202502257](https://advanced.onlinelibrary.wiley.com/doi/10.1002/advs.202502257)

\[369] Borophene: Synthesis, Chemistry, and Electronic Properties[ https://chemistry-europe.onlinelibrary.wiley.com/doi/10.1002/cplu.202400333?af=R](https://chemistry-europe.onlinelibrary.wiley.com/doi/10.1002/cplu.202400333?af=R)

\[370] Borophene: Synthesis, Properties and Experimental HEvolution Potential Applications[ https://www.mdpi.com/2073-4352/15/9/753/xml](https://www.mdpi.com/2073-4352/15/9/753/xml)

\[371] Cryo-Exfoliation Synthesis of Borophene and its Application in Wearable Electronics[ https://pmc.ncbi.nlm.nih.gov/articles/PMC12245121/pdf/ADVS-12-2502257.pdf](https://pmc.ncbi.nlm.nih.gov/articles/PMC12245121/pdf/ADVS-12-2502257.pdf)

\[372] Borophene nanomaterials: synthesis and applications in biosensors[ https://pubs.rsc.org/en/content/articlepdf/2024/MA/D3MA00829K](https://pubs.rsc.org/en/content/articlepdf/2024/MA/D3MA00829K)