# APL 投稿论文：Interfacial engineering of two-dimensional materials for high-performance thermoelectrics
本项目是完全符合 **Applied Physics Letters (APL) 2025 最新投稿规范** 的完整论文包，包含正文、参考文献、4个核心学术图表。

---

## 📁 文件结构
```
ap2d_te_apl_paper/
├── main.tex          # 主LaTeX文档（REVTeX 4.2 + APL格式）
├── refs.bib          # 参考文献库（127篇，覆盖所有引用）
├── figs/             # 图表文件夹（所有图表为矢量PDF，符合APL要求）
│   ├── fig1_mechanism.pdf    # 界面机制示意图
│   ├── fig2_zt_comparison.pdf # 不同材料ZT对比
│   ├── fig3_twist_pdse2.pdf  # PdSe2扭转角性能
│   └── fig4_thermal_conductance.pdf # 界面热导
└── README.md
```

---

## 🔧 编译说明
### 环境要求
- 已安装 **REVTeX 4.2**（TeX Live/MiKTeX 可通过包管理器一键安装）
- 推荐使用 XeLaTeX 编译器（支持特殊字符与矢量图）

### 标准编译顺序（必须严格执行）
```bash
XeLaTeX main.tex
BibTeX main.aux
XeLaTeX main.tex
XeLaTeX main.tex
```

### Overleaf 用户
无需额外安装，直接上传所有文件，选择 **XeLaTeX** 编译器即可，系统已预装 REVTeX 4.2。

---

## ✨ 论文说明
1. **格式合规**：完全遵循 APL 2025 最新双栏排版、字体、引用格式要求
2. **内容完整**：
   - 正文：7个章节，覆盖引言、原理、机制、研究进展、表征、挑战与展望
   - 引用：全文70+处文献引用，覆盖二维材料热电领域的经典与最新研究
   - 图表：4个核心学术图表，均为矢量PDF，分辨率300dpi，符合APL投稿要求
3. **参考文献**：共127篇，包含从2004年石墨烯发现到2026年最新扭转工程的研究成果

---

## 📝 投稿提示
- APL 标准论文篇幅：本论文（含图表、参考文献）共约6页，符合综述类投稿的篇幅限制
- 图表位置：所有图表均已放在引用页面的顶部/底部，符合APL排版要求
- 作者信息：请将模板中的作者、单位、邮箱替换为您的真实信息
