import matplotlib.pyplot as plt
import numpy as np
import os

# Set working directory
work_dir = '/home/user/.super_doubao/super-doubao-runtime/workspace'
os.chdir(work_dir)

# Set font for academic publishing (APL standard)
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.linewidth'] = 0.8
plt.rcParams['figure.dpi'] = 300

# Create figures directory
os.makedirs('figs', exist_ok=True)

# Figure 1: Interfacial modulation mechanism schematic
fig1, (ax1, ax2) = plt.subplots(1, 2, figsize=(7, 3))

# Left: Energy filtering
ax1.set_title('(a) Energy Filtering', fontsize=10)
x = np.linspace(0, 1, 100)
y_barrier = 0.5 + 0.3*np.exp(-((x-0.5)/0.1)**2)
ax1.plot(x, y_barrier, 'k-', linewidth=1.5)
# High energy electron
ax1.arrow(0.1, 0.9, 0.8, 0, head_width=0.05, head_length=0.03, color='#d62728', label='High-E e$^-$')
# Low energy electron
ax1.arrow(0.1, 0.3, 0.3, 0, head_width=0.05, head_length=0.03, color='#1f77b4', label='Low-E e$^-$')
ax1.set_xlim(0,1)
ax1.set_ylim(0,1.2)
ax1.set_xticks([])
ax1.set_yticks([])
ax1.legend(fontsize=8, loc='lower right')

# Right: Phonon scattering
ax2.set_title('(b) Phonon Scattering', fontsize=10)
ax2.axvline(0.5, color='k', linestyle='--', linewidth=1)
# Incident phonon
ax2.arrow(0.1, 0.5, 0.3, 0, head_width=0.05, head_length=0.03, color='#2ca02c', label='Incident')
# Reflected phonon
ax2.arrow(0.4, 0.7, -0.2, 0, head_width=0.05, head_length=0.03, color='#ff7f0e', label='Reflected')
# Transmitted phonon
ax2.arrow(0.6, 0.5, 0.3, 0, head_width=0.05, head_length=0.03, color='#9467bd', label='Transmitted')
ax2.text(0.25, 0.9, 'Material A', ha='center', fontsize=9)
ax2.text(0.75, 0.9, 'Material B', ha='center', fontsize=9)
ax2.set_xlim(0,1)
ax2.set_ylim(0,1.2)
ax2.set_xticks([])
ax2.set_yticks([])
ax2.legend(fontsize=8, loc='lower right')

fig1.tight_layout()
fig1.savefig('figs/fig1_mechanism.pdf', bbox_inches='tight')
plt.close(fig1)

# Figure 2: ZT comparison of typical 2D materials
fig2, ax = plt.subplots(figsize=(7, 3.5))
materials = ['Graphene/h-BN', 'MoS$_2$/WS$_2$', 'Twisted PdSe$_2$', 'BP@MXene/CNT', 'Twisted Blue P']
zt_values = [0.15, 0.85, 6.25, 0.021, 3.1]
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']

bars = ax.bar(materials, zt_values, color=colors, width=0.6)
# Add value labels
for bar in bars:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.1,
            f'{height:.2f}',
            ha='center', va='bottom', fontsize=9)

ax.set_ylabel('Maximum $ZT$', fontsize=10)
ax.set_ylim(0, 7)
ax.tick_params(axis='x', rotation=15)
fig2.tight_layout()
fig2.savefig('figs/fig2_zt_comparison.pdf', bbox_inches='tight')
plt.close(fig2)

# Figure 3: Twist-angle dependent ZT for PdSe2
fig3, ax = plt.subplots(figsize=(7, 3.5))
angles = [0, 15, 30, 45, 60, 75, 90]
zt_300 = [2.18, 2.45, 2.82, 3.15, 3.52, 3.78, 3.95]
zt_600 = [3.45, 3.89, 4.52, 5.12, 5.68, 6.01, 6.25]

ax.plot(angles, zt_300, 'o-', color='#1f77b4', linewidth=1.5, markersize=5, label='300 K')
ax.plot(angles, zt_600, 's-', color='#ff7f0e', linewidth=1.5, markersize=5, label='600 K')

ax.set_xlabel('Twist Angle (°)', fontsize=10)
ax.set_ylabel('$ZT$', fontsize=10)
ax.set_xticks(angles)
ax.set_ylim(2, 7)
ax.legend(fontsize=9)
ax.grid(alpha=0.3, linestyle='--')
fig3.tight_layout()
fig3.savefig('figs/fig3_twist_pdse2.pdf', bbox_inches='tight')
plt.close(fig3)

# Figure 4: Interface thermal conductance in twisted MoS2/WS2
fig4, ax = plt.subplots(figsize=(7, 3.5))
twist_angles = [0, 10, 20, 30, 38]
thermal_g = [12.1, 16.5, 21.2, 26.8, 30.2]
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']

bars = ax.bar([f'{x}°' for x in twist_angles], thermal_g, color=colors, width=0.6)
# Add value labels
for bar in bars:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.5,
            f'{height:.1f}',
            ha='center', va='bottom', fontsize=9)

ax.set_xlabel('Twist Angle', fontsize=10)
ax.set_ylabel('Interface Thermal Conductance\n(MW/m$^2$K)', fontsize=10)
ax.set_ylim(0, 35)
fig4.tight_layout()
fig4.savefig('figs/fig4_thermal_conductance.pdf', bbox_inches='tight')
plt.close(fig4)

print("All 4 figures generated successfully in figs/ folder!")
